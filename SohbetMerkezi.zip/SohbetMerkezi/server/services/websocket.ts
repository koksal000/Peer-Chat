import { WebSocketServer, WebSocket } from 'ws';
import { Server } from 'http';
import { WSMessage } from '@shared/schema';

export interface ConnectedUser {
  userId: string;
  peerId: string;
  socket: WebSocket;
  lastSeen: Date;
}

export class WebSocketService {
  private wss: WebSocketServer | null = null;
  private connections: Map<string, ConnectedUser> = new Map();
  private userSockets: Map<string, WebSocket> = new Map();

  initialize(server: Server): void {
    this.wss = new WebSocketServer({ 
      server, 
      path: '/ws',
      clientTracking: true 
    });

    this.wss.on('connection', (socket: WebSocket, request) => {
      console.log('New WebSocket connection');

      socket.on('message', (data) => {
        try {
          const message = JSON.parse(data.toString()) as WSMessage & { userId?: string };
          this.handleMessage(socket, message);
        } catch (error) {
          console.error('Invalid WebSocket message:', error);
          socket.send(JSON.stringify({ 
            type: 'error', 
            data: { message: 'Invalid message format' } 
          }));
        }
      });

      socket.on('close', () => {
        this.handleDisconnection(socket);
      });

      socket.on('error', (error) => {
        console.error('WebSocket error:', error);
        this.handleDisconnection(socket);
      });

      // Send connection acknowledgment
      socket.send(JSON.stringify({ 
        type: 'connected', 
        data: { message: 'WebSocket connection established' } 
      }));
    });
  }

  private handleMessage(socket: WebSocket, message: WSMessage & { userId?: string }): void {
    switch (message.type) {
      case 'register':
        this.handleUserRegistration(socket, message);
        break;
      case 'message':
        this.handleChatMessage(message);
        break;
      case 'typing':
        this.handleTypingIndicator(message);
        break;
      case 'status':
        this.handleStatusUpdate(message);
        break;
      case 'call':
        this.handleCallSignaling(message);
        break;
      default:
        console.log('Unknown message type:', message.type);
    }
  }

  private handleUserRegistration(socket: WebSocket, message: WSMessage & { userId?: string }): void {
    const { userId, peerId } = message.data;
    
    if (!userId || !peerId) {
      socket.send(JSON.stringify({ 
        type: 'error', 
        data: { message: 'userId and peerId required for registration' } 
      }));
      return;
    }

    // Remove old connection if exists
    if (this.userSockets.has(userId)) {
      const oldSocket = this.userSockets.get(userId);
      if (oldSocket && oldSocket.readyState === WebSocket.OPEN) {
        oldSocket.close();
      }
    }

    // Register new connection
    this.connections.set(socket.toString(), {
      userId,
      peerId,
      socket,
      lastSeen: new Date()
    });
    
    this.userSockets.set(userId, socket);

    // Broadcast user online status
    this.broadcastToContacts(userId, {
      type: 'status',
      data: { userId, isOnline: true }
    });

    socket.send(JSON.stringify({ 
      type: 'registered', 
      data: { userId, peerId, message: 'Successfully registered' } 
    }));
  }

  private handleChatMessage(message: WSMessage): void {
    const { targetUser, chatId } = message;
    
    if (targetUser) {
      // Direct message to specific user
      this.sendToUser(targetUser, message);
    } else if (chatId) {
      // Group message - broadcast to all participants
      this.broadcastToChat(chatId, message);
    }
  }

  private handleTypingIndicator(message: WSMessage): void {
    const { targetUser, chatId } = message;
    
    if (targetUser) {
      this.sendToUser(targetUser, message);
    } else if (chatId) {
      this.broadcastToChat(chatId, message);
    }
  }

  private handleStatusUpdate(message: WSMessage): void {
    // Broadcast status update to user's contacts
    const userId = message.data?.userId;
    if (userId) {
      this.broadcastToContacts(userId, message);
    }
  }

  private handleCallSignaling(message: WSMessage): void {
    const { targetUser } = message;
    if (targetUser) {
      this.sendToUser(targetUser, message);
    }
  }

  private handleDisconnection(socket: WebSocket): void {
    const connectionKey = socket.toString();
    const connection = this.connections.get(connectionKey);
    
    if (connection) {
      const { userId } = connection;
      
      // Remove from connections
      this.connections.delete(connectionKey);
      this.userSockets.delete(userId);
      
      // Broadcast user offline status
      this.broadcastToContacts(userId, {
        type: 'status',
        data: { userId, isOnline: false, lastSeen: new Date() }
      });
      
      console.log(`User ${userId} disconnected`);
    }
  }

  public sendToUser(userId: string, message: WSMessage): boolean {
    const socket = this.userSockets.get(userId);
    
    if (socket && socket.readyState === WebSocket.OPEN) {
      socket.send(JSON.stringify(message));
      return true;
    }
    
    return false;
  }

  public broadcastToChat(chatId: string, message: WSMessage, excludeUserId?: string): void {
    // In a real implementation, you'd get chat participants from database
    // For now, we'll broadcast to all connected users except sender
    this.connections.forEach((connection) => {
      if (connection.userId !== excludeUserId && connection.socket.readyState === WebSocket.OPEN) {
        connection.socket.send(JSON.stringify(message));
      }
    });
  }

  public broadcastToContacts(userId: string, message: WSMessage): void {
    // In a real implementation, you'd get user's contacts from database
    // For now, we'll broadcast to all connected users
    this.connections.forEach((connection) => {
      if (connection.userId !== userId && connection.socket.readyState === WebSocket.OPEN) {
        connection.socket.send(JSON.stringify(message));
      }
    });
  }

  public getOnlineUsers(): string[] {
    return Array.from(this.userSockets.keys());
  }

  public isUserOnline(userId: string): boolean {
    const socket = this.userSockets.get(userId);
    return socket !== undefined && socket.readyState === WebSocket.OPEN;
  }
}

export const wsService = new WebSocketService();
