import { GoogleGenerativeAI } from '@google/generative-ai';

// Initialize Gemini AI with API key from environment
const genAI = new GoogleGenerativeAI(
  process.env.GEMINI_API_KEY || process.env.GOOGLE_AI_API_KEY || ""
);

export class GeminiService {
  private model = genAI.getGenerativeModel({ model: "gemini-2.5-flash" });

  async generateResponse(prompt: string, context?: string): Promise<string> {
    try {
      const fullPrompt = context 
        ? `Context: ${context}\n\nUser: ${prompt}\n\nAssistant:`
        : prompt;

      const result = await this.model.generateContent(fullPrompt);
      const response = await result.response;
      return response.text() || "I apologize, but I couldn't generate a response at the moment.";
    } catch (error) {
      console.error('Gemini API error:', error);
      throw new Error('Failed to generate AI response');
    }
  }

  async analyzeImage(imageData: string, mimeType: string, prompt?: string): Promise<string> {
    try {
      const imagePart = {
        inlineData: {
          data: imageData,
          mimeType: mimeType
        }
      };

      const analysisPrompt = prompt || "Analyze this image and describe what you see in detail.";
      
      const result = await this.model.generateContent([analysisPrompt, imagePart]);
      const response = await result.response;
      return response.text() || "I couldn't analyze this image.";
    } catch (error) {
      console.error('Gemini image analysis error:', error);
      throw new Error('Failed to analyze image');
    }
  }

  async generateCodeResponse(codeRequest: string, language?: string): Promise<string> {
    try {
      const systemPrompt = `You are a helpful coding assistant. Provide clean, well-commented code solutions.`;
      const fullPrompt = language 
        ? `${systemPrompt}\n\nLanguage: ${language}\nRequest: ${codeRequest}`
        : `${systemPrompt}\n\nRequest: ${codeRequest}`;

      const result = await this.model.generateContent(fullPrompt);
      const response = await result.response;
      return response.text() || "I couldn't generate code for that request.";
    } catch (error) {
      console.error('Gemini code generation error:', error);
      throw new Error('Failed to generate code response');
    }
  }

  async summarizeConversation(messages: string[]): Promise<string> {
    try {
      const conversation = messages.join('\n');
      const prompt = `Summarize the following conversation concisely:\n\n${conversation}`;

      const result = await this.model.generateContent(prompt);
      const response = await result.response;
      return response.text() || "Couldn't summarize the conversation.";
    } catch (error) {
      console.error('Gemini summarization error:', error);
      throw new Error('Failed to summarize conversation');
    }
  }
}

export const geminiService = new GeminiService();
