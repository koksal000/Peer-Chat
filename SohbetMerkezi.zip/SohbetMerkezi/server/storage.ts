import { 
  User, InsertUser, Contact, InsertContact, Chat, InsertChat, 
  Message, InsertMessage, StatusUpdate, InsertStatus, FileUpload,
  users, contacts, chats, messages, statusUpdates, files, 
  chatParticipants, messageStatus, statusViews
} from "@shared/schema";
import { randomUUID } from "crypto";
import { eq, and, or, desc, asc } from "drizzle-orm";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByPeerId(peerId: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserStatus(id: string, isOnline: boolean): Promise<void>;
  
  // Contact methods
  getContacts(userId: string): Promise<Contact[]>;
  addContact(contact: InsertContact): Promise<Contact>;
  removeContact(userId: string, contactId: string): Promise<void>;
  blockContact(userId: string, contactId: string, blocked: boolean): Promise<void>;
  
  // Chat methods
  getChats(userId: string): Promise<Chat[]>;
  getChat(chatId: string): Promise<Chat | undefined>;
  createChat(chat: InsertChat): Promise<Chat>;
  addChatParticipant(chatId: string, userId: string, role?: string): Promise<void>;
  removeChatParticipant(chatId: string, userId: string): Promise<void>;
  getChatParticipants(chatId: string): Promise<string[]>;
  
  // Message methods
  getMessages(chatId: string, limit?: number): Promise<Message[]>;
  getMessage(messageId: string): Promise<Message | undefined>;
  createMessage(message: InsertMessage): Promise<Message>;
  updateMessageStatus(messageId: string, userId: string, status: string): Promise<void>;
  deleteMessage(messageId: string): Promise<void>;
  
  // Status methods
  getStatusUpdates(userId: string): Promise<StatusUpdate[]>;
  getContactsStatus(userId: string): Promise<StatusUpdate[]>;
  createStatus(status: InsertStatus): Promise<StatusUpdate>;
  viewStatus(statusId: string, viewerId: string): Promise<void>;
  
  // File methods
  saveFile(file: Omit<FileUpload, 'id' | 'uploadedAt'>): Promise<FileUpload>;
  getFile(fileId: string): Promise<FileUpload | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User> = new Map();
  private contacts: Map<string, Contact> = new Map();
  private chats: Map<string, Chat> = new Map();
  private messages: Map<string, Message> = new Map();
  private statusUpdates: Map<string, StatusUpdate> = new Map();
  private files: Map<string, FileUpload> = new Map();
  private chatParticipants: Map<string, string[]> = new Map();
  private messageStatuses: Map<string, Map<string, string>> = new Map();

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByPeerId(peerId: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.peerId === peerId);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = {
      ...insertUser,
      id,
      isOnline: false,
      lastSeen: new Date(),
      createdAt: new Date(),
    };
    this.users.set(id, user);
    return user;
  }

  async updateUserStatus(id: string, isOnline: boolean): Promise<void> {
    const user = this.users.get(id);
    if (user) {
      user.isOnline = isOnline;
      user.lastSeen = new Date();
      this.users.set(id, user);
    }
  }

  async getContacts(userId: string): Promise<Contact[]> {
    return Array.from(this.contacts.values()).filter(contact => contact.userId === userId);
  }

  async addContact(contact: InsertContact): Promise<Contact> {
    const id = randomUUID();
    const newContact: Contact = {
      ...contact,
      id,
      isBlocked: false,
      createdAt: new Date(),
    };
    this.contacts.set(id, newContact);
    return newContact;
  }

  async removeContact(userId: string, contactId: string): Promise<void> {
    const contact = Array.from(this.contacts.values()).find(
      c => c.userId === userId && c.contactId === contactId
    );
    if (contact) {
      this.contacts.delete(contact.id);
    }
  }

  async blockContact(userId: string, contactId: string, blocked: boolean): Promise<void> {
    const contact = Array.from(this.contacts.values()).find(
      c => c.userId === userId && c.contactId === contactId
    );
    if (contact) {
      contact.isBlocked = blocked;
      this.contacts.set(contact.id, contact);
    }
  }

  async getChats(userId: string): Promise<Chat[]> {
    const userChats = Array.from(this.chatParticipants.entries())
      .filter(([_, participants]) => participants.includes(userId))
      .map(([chatId]) => this.chats.get(chatId))
      .filter(Boolean) as Chat[];
    
    return userChats.sort((a, b) => b.updatedAt!.getTime() - a.updatedAt!.getTime());
  }

  async getChat(chatId: string): Promise<Chat | undefined> {
    return this.chats.get(chatId);
  }

  async createChat(chat: InsertChat): Promise<Chat> {
    const id = randomUUID();
    const newChat: Chat = {
      ...chat,
      id,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.chats.set(id, newChat);
    this.chatParticipants.set(id, []);
    return newChat;
  }

  async addChatParticipant(chatId: string, userId: string, role = 'member'): Promise<void> {
    const participants = this.chatParticipants.get(chatId) || [];
    if (!participants.includes(userId)) {
      participants.push(userId);
      this.chatParticipants.set(chatId, participants);
    }
  }

  async removeChatParticipant(chatId: string, userId: string): Promise<void> {
    const participants = this.chatParticipants.get(chatId) || [];
    const filtered = participants.filter(id => id !== userId);
    this.chatParticipants.set(chatId, filtered);
  }

  async getChatParticipants(chatId: string): Promise<string[]> {
    return this.chatParticipants.get(chatId) || [];
  }

  async getMessages(chatId: string, limit = 50): Promise<Message[]> {
    const chatMessages = Array.from(this.messages.values())
      .filter(msg => msg.chatId === chatId && !msg.isDeleted)
      .sort((a, b) => a.timestamp!.getTime() - b.timestamp!.getTime())
      .slice(-limit);
    
    return chatMessages;
  }

  async getMessage(messageId: string): Promise<Message | undefined> {
    return this.messages.get(messageId);
  }

  async createMessage(message: InsertMessage): Promise<Message> {
    const id = randomUUID();
    const newMessage: Message = {
      ...message,
      id,
      isEdited: false,
      isDeleted: false,
      timestamp: new Date(),
    };
    this.messages.set(id, newMessage);
    
    // Update chat's updatedAt
    const chat = this.chats.get(message.chatId);
    if (chat) {
      chat.updatedAt = new Date();
      this.chats.set(message.chatId, chat);
    }
    
    return newMessage;
  }

  async updateMessageStatus(messageId: string, userId: string, status: string): Promise<void> {
    if (!this.messageStatuses.has(messageId)) {
      this.messageStatuses.set(messageId, new Map());
    }
    this.messageStatuses.get(messageId)!.set(userId, status);
  }

  async deleteMessage(messageId: string): Promise<void> {
    const message = this.messages.get(messageId);
    if (message) {
      message.isDeleted = true;
      this.messages.set(messageId, message);
    }
  }

  async getStatusUpdates(userId: string): Promise<StatusUpdate[]> {
    return Array.from(this.statusUpdates.values())
      .filter(status => status.userId === userId)
      .sort((a, b) => b.createdAt!.getTime() - a.createdAt!.getTime());
  }

  async getContactsStatus(userId: string): Promise<StatusUpdate[]> {
    const userContacts = await this.getContacts(userId);
    const contactIds = userContacts.map(c => c.contactId);
    
    return Array.from(this.statusUpdates.values())
      .filter(status => contactIds.includes(status.userId))
      .sort((a, b) => b.createdAt!.getTime() - a.createdAt!.getTime());
  }

  async createStatus(status: InsertStatus): Promise<StatusUpdate> {
    const id = randomUUID();
    const expiresAt = new Date();
    expiresAt.setHours(expiresAt.getHours() + 24); // 24 hours from now
    
    const newStatus: StatusUpdate = {
      ...status,
      id,
      viewCount: 0,
      createdAt: new Date(),
      expiresAt,
    };
    this.statusUpdates.set(id, newStatus);
    return newStatus;
  }

  async viewStatus(statusId: string, viewerId: string): Promise<void> {
    const status = this.statusUpdates.get(statusId);
    if (status && status.userId !== viewerId) {
      status.viewCount = (status.viewCount || 0) + 1;
      this.statusUpdates.set(statusId, status);
    }
  }

  async saveFile(file: Omit<FileUpload, 'id' | 'uploadedAt'>): Promise<FileUpload> {
    const id = randomUUID();
    const newFile: FileUpload = {
      ...file,
      id,
      uploadedAt: new Date(),
    };
    this.files.set(id, newFile);
    return newFile;
  }

  async getFile(fileId: string): Promise<FileUpload | undefined> {
    return this.files.get(fileId);
  }
}

export const storage = new MemStorage();
