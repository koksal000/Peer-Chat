import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertContactSchema, insertChatSchema, insertMessageSchema, insertStatusSchema } from "@shared/schema";
import { geminiService } from "./services/gemini";
import { wsService } from "./services/websocket";
import { upload, fileUploadService } from "./services/fileUpload";
import path from "path";
import fs from "fs";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // Initialize WebSocket service
  wsService.initialize(httpServer);

  // User routes
  app.post('/api/users', async (req: Request, res: Response) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user with same username or peerId already exists
      const existingUser = await storage.getUserByUsername(userData.username) || 
                          await storage.getUserByPeerId(userData.peerId);
      
      if (existingUser) {
        return res.status(400).json({ message: 'User with this username or peer ID already exists' });
      }

      const user = await storage.createUser(userData);
      res.status(201).json(user);
    } catch (error: any) {
      res.status(400).json({ message: error.message || 'Failed to create user' });
    }
  });

  app.get('/api/users/:id', async (req: Request, res: Response) => {
    try {
      const user = await storage.getUser(req.params.id);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      res.json(user);
    } catch (error: any) {
      res.status(500).json({ message: error.message || 'Failed to get user' });
    }
  });

  app.get('/api/users/peer/:peerId', async (req: Request, res: Response) => {
    try {
      const user = await storage.getUserByPeerId(req.params.peerId);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      res.json(user);
    } catch (error: any) {
      res.status(500).json({ message: error.message || 'Failed to get user' });
    }
  });

  app.patch('/api/users/:id/status', async (req: Request, res: Response) => {
    try {
      const { isOnline } = req.body;
      await storage.updateUserStatus(req.params.id, isOnline);
      res.json({ message: 'Status updated successfully' });
    } catch (error: any) {
      res.status(500).json({ message: error.message || 'Failed to update status' });
    }
  });

  // Contact routes
  app.get('/api/contacts/:userId', async (req: Request, res: Response) => {
    try {
      const contacts = await storage.getContacts(req.params.userId);
      res.json(contacts);
    } catch (error: any) {
      res.status(500).json({ message: error.message || 'Failed to get contacts' });
    }
  });

  app.post('/api/contacts', async (req: Request, res: Response) => {
    try {
      const contactData = insertContactSchema.parse(req.body);
      
      // Verify contact user exists
      const contactUser = await storage.getUser(contactData.contactId);
      if (!contactUser) {
        return res.status(404).json({ message: 'Contact user not found' });
      }

      const contact = await storage.addContact(contactData);
      res.status(201).json(contact);
    } catch (error: any) {
      res.status(400).json({ message: error.message || 'Failed to add contact' });
    }
  });

  app.delete('/api/contacts/:userId/:contactId', async (req: Request, res: Response) => {
    try {
      await storage.removeContact(req.params.userId, req.params.contactId);
      res.json({ message: 'Contact removed successfully' });
    } catch (error: any) {
      res.status(500).json({ message: error.message || 'Failed to remove contact' });
    }
  });

  app.patch('/api/contacts/:userId/:contactId/block', async (req: Request, res: Response) => {
    try {
      const { blocked } = req.body;
      await storage.blockContact(req.params.userId, req.params.contactId, blocked);
      res.json({ message: `Contact ${blocked ? 'blocked' : 'unblocked'} successfully` });
    } catch (error: any) {
      res.status(500).json({ message: error.message || 'Failed to update contact' });
    }
  });

  // Chat routes
  app.get('/api/chats/:userId', async (req: Request, res: Response) => {
    try {
      const chats = await storage.getChats(req.params.userId);
      res.json(chats);
    } catch (error: any) {
      res.status(500).json({ message: error.message || 'Failed to get chats' });
    }
  });

  app.post('/api/chats', async (req: Request, res: Response) => {
    try {
      const chatData = insertChatSchema.parse(req.body);
      const chat = await storage.createChat(chatData);
      
      // Add creator as participant
      if (chatData.createdBy) {
        await storage.addChatParticipant(chat.id, chatData.createdBy, 'admin');
      }

      res.status(201).json(chat);
    } catch (error: any) {
      res.status(400).json({ message: error.message || 'Failed to create chat' });
    }
  });

  app.post('/api/chats/:chatId/participants', async (req: Request, res: Response) => {
    try {
      const { userId, role = 'member' } = req.body;
      await storage.addChatParticipant(req.params.chatId, userId, role);
      res.json({ message: 'Participant added successfully' });
    } catch (error: any) {
      res.status(500).json({ message: error.message || 'Failed to add participant' });
    }
  });

  app.delete('/api/chats/:chatId/participants/:userId', async (req: Request, res: Response) => {
    try {
      await storage.removeChatParticipant(req.params.chatId, req.params.userId);
      res.json({ message: 'Participant removed successfully' });
    } catch (error: any) {
      res.status(500).json({ message: error.message || 'Failed to remove participant' });
    }
  });

  // Message routes
  app.get('/api/messages/:chatId', async (req: Request, res: Response) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 50;
      const messages = await storage.getMessages(req.params.chatId, limit);
      res.json(messages);
    } catch (error: any) {
      res.status(500).json({ message: error.message || 'Failed to get messages' });
    }
  });

  app.post('/api/messages', async (req: Request, res: Response) => {
    try {
      const messageData = insertMessageSchema.parse(req.body);
      const message = await storage.createMessage(messageData);
      
      // Broadcast message via WebSocket
      wsService.broadcastToChat(messageData.chatId, {
        type: 'message',
        data: message,
        chatId: messageData.chatId
      }, messageData.senderId);

      res.status(201).json(message);
    } catch (error: any) {
      res.status(400).json({ message: error.message || 'Failed to create message' });
    }
  });

  app.patch('/api/messages/:messageId/status', async (req: Request, res: Response) => {
    try {
      const { userId, status } = req.body;
      await storage.updateMessageStatus(req.params.messageId, userId, status);
      res.json({ message: 'Message status updated' });
    } catch (error: any) {
      res.status(500).json({ message: error.message || 'Failed to update message status' });
    }
  });

  app.delete('/api/messages/:messageId', async (req: Request, res: Response) => {
    try {
      await storage.deleteMessage(req.params.messageId);
      res.json({ message: 'Message deleted successfully' });
    } catch (error: any) {
      res.status(500).json({ message: error.message || 'Failed to delete message' });
    }
  });

  // Gemini AI routes
  app.post('/api/ai/chat', async (req: Request, res: Response) => {
    try {
      const { prompt, context } = req.body;
      
      if (!prompt) {
        return res.status(400).json({ message: 'Prompt is required' });
      }

      const response = await geminiService.generateResponse(prompt, context);
      res.json({ response });
    } catch (error: any) {
      res.status(500).json({ message: error.message || 'Failed to generate AI response' });
    }
  });

  app.post('/api/ai/analyze-image', upload.single('image'), async (req: Request, res: Response) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: 'Image file is required' });
      }

      const imageData = fs.readFileSync(req.file.path, { encoding: 'base64' });
      const analysis = await geminiService.analyzeImage(imageData, req.file.mimetype, req.body.prompt);
      
      // Clean up uploaded file
      fs.unlinkSync(req.file.path);
      
      res.json({ analysis });
    } catch (error: any) {
      res.status(500).json({ message: error.message || 'Failed to analyze image' });
    }
  });

  app.post('/api/ai/code', async (req: Request, res: Response) => {
    try {
      const { request, language } = req.body;
      
      if (!request) {
        return res.status(400).json({ message: 'Code request is required' });
      }

      const response = await geminiService.generateCodeResponse(request, language);
      res.json({ response });
    } catch (error: any) {
      res.status(500).json({ message: error.message || 'Failed to generate code response' });
    }
  });

  // Status routes
  app.get('/api/status/:userId', async (req: Request, res: Response) => {
    try {
      const statusUpdates = await storage.getStatusUpdates(req.params.userId);
      res.json(statusUpdates);
    } catch (error: any) {
      res.status(500).json({ message: error.message || 'Failed to get status updates' });
    }
  });

  app.get('/api/status/contacts/:userId', async (req: Request, res: Response) => {
    try {
      const statusUpdates = await storage.getContactsStatus(req.params.userId);
      res.json(statusUpdates);
    } catch (error: any) {
      res.status(500).json({ message: error.message || 'Failed to get contacts status' });
    }
  });

  app.post('/api/status', upload.single('media'), async (req: Request, res: Response) => {
    try {
      const statusData = insertStatusSchema.parse(req.body);
      
      // If media file uploaded, save it
      if (req.file) {
        const fileInfo = await fileUploadService.saveFileInfo(req.file, statusData.userId);
        statusData.content = `/api/files/${fileInfo.id}`;
        statusData.type = fileUploadService.getFileTypeCategory(req.file.mimetype) as any;
      }

      const status = await storage.createStatus(statusData);
      
      // Broadcast status update
      wsService.broadcastToContacts(statusData.userId, {
        type: 'status',
        data: status
      });

      res.status(201).json(status);
    } catch (error: any) {
      res.status(400).json({ message: error.message || 'Failed to create status' });
    }
  });

  app.post('/api/status/:statusId/view', async (req: Request, res: Response) => {
    try {
      const { viewerId } = req.body;
      await storage.viewStatus(req.params.statusId, viewerId);
      res.json({ message: 'Status viewed' });
    } catch (error: any) {
      res.status(500).json({ message: error.message || 'Failed to record status view' });
    }
  });

  // File upload routes
  app.post('/api/upload', upload.array('files', 5), async (req: Request, res: Response) => {
    try {
      const files = req.files as Express.Multer.File[];
      const { uploadedBy } = req.body;

      if (!files || files.length === 0) {
        return res.status(400).json({ message: 'No files uploaded' });
      }

      if (!uploadedBy) {
        return res.status(400).json({ message: 'uploadedBy is required' });
      }

      const fileInfos = await Promise.all(
        files.map(file => fileUploadService.saveFileInfo(file, uploadedBy))
      );

      res.status(201).json(fileInfos);
    } catch (error: any) {
      res.status(400).json({ message: error.message || 'Failed to upload files' });
    }
  });

  app.get('/api/files/:fileId', async (req: Request, res: Response) => {
    try {
      const filePath = await fileUploadService.getFilePath(req.params.fileId);
      
      if (!filePath || !fs.existsSync(filePath)) {
        return res.status(404).json({ message: 'File not found' });
      }

      const stat = fs.statSync(filePath);
      const fileSize = stat.size;
      const range = req.headers.range;

      if (range) {
        // Support for video streaming
        const parts = range.replace(/bytes=/, "").split("-");
        const start = parseInt(parts[0], 10);
        const end = parts[1] ? parseInt(parts[1], 10) : fileSize - 1;
        const chunksize = (end - start) + 1;
        const file = fs.createReadStream(filePath, { start, end });
        const head = {
          'Content-Range': `bytes ${start}-${end}/${fileSize}`,
          'Accept-Ranges': 'bytes',
          'Content-Length': chunksize,
          'Content-Type': 'application/octet-stream',
        };
        res.writeHead(206, head);
        file.pipe(res);
      } else {
        const head = {
          'Content-Length': fileSize,
          'Content-Type': 'application/octet-stream',
        };
        res.writeHead(200, head);
        fs.createReadStream(filePath).pipe(res);
      }
    } catch (error: any) {
      res.status(500).json({ message: error.message || 'Failed to serve file' });
    }
  });

  // Health check
  app.get('/api/health', (req: Request, res: Response) => {
    res.json({ 
      status: 'healthy', 
      timestamp: new Date().toISOString(),
      onlineUsers: wsService.getOnlineUsers().length
    });
  });

  return httpServer;
}
