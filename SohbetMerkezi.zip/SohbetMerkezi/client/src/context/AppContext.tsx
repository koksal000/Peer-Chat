import React, { createContext, useContext, useReducer, useEffect } from 'react';
import { User, Chat, Contact, Group, Message, StatusUpdate, UnknownMessage, ConnectionStatus, Theme, TabType } from '../types';

interface AppState {
  currentUser: User | null;
  activeChat: string | null;
  activeTab: TabType;
  chats: Chat[];
  contacts: Contact[];
  groups: Group[];
  messages: Record<string, Message[]>;
  statusUpdates: StatusUpdate[];
  unknownMessages: UnknownMessage[];
  connectionStatus: ConnectionStatus;
  theme: Theme;
  isLoading: boolean;
  error: string | null;
}

type AppAction =
  | { type: 'SET_USER'; payload: User }
  | { type: 'SET_ACTIVE_CHAT'; payload: string | null }
  | { type: 'SET_ACTIVE_TAB'; payload: TabType }
  | { type: 'SET_CHATS'; payload: Chat[] }
  | { type: 'SET_CONTACTS'; payload: Contact[] }
  | { type: 'SET_GROUPS'; payload: Group[] }
  | { type: 'ADD_MESSAGE'; payload: { chatId: string; message: Message } }
  | { type: 'SET_MESSAGES'; payload: { chatId: string; messages: Message[] } }
  | { type: 'SET_STATUS_UPDATES'; payload: StatusUpdate[] }
  | { type: 'SET_UNKNOWN_MESSAGES'; payload: UnknownMessage[] }
  | { type: 'SET_CONNECTION_STATUS'; payload: ConnectionStatus }
  | { type: 'SET_THEME'; payload: Theme }
  | { type: 'SET_LOADING'; payload: boolean }
  | { type: 'SET_ERROR'; payload: string | null };

const initialState: AppState = {
  currentUser: null,
  activeChat: null,
  activeTab: 'chats',
  chats: [],
  contacts: [],
  groups: [],
  messages: {},
  statusUpdates: [],
  unknownMessages: [],
  connectionStatus: 'disconnected',
  theme: 'light',
  isLoading: false,
  error: null,
};

function appReducer(state: AppState, action: AppAction): AppState {
  switch (action.type) {
    case 'SET_USER':
      return { ...state, currentUser: action.payload };
    case 'SET_ACTIVE_CHAT':
      return { ...state, activeChat: action.payload };
    case 'SET_ACTIVE_TAB':
      return { ...state, activeTab: action.payload };
    case 'SET_CHATS':
      return { ...state, chats: action.payload };
    case 'SET_CONTACTS':
      return { ...state, contacts: action.payload };
    case 'SET_GROUPS':
      return { ...state, groups: action.payload };
    case 'ADD_MESSAGE':
      return {
        ...state,
        messages: {
          ...state.messages,
          [action.payload.chatId]: [
            ...(state.messages[action.payload.chatId] || []),
            action.payload.message,
          ],
        },
      };
    case 'SET_MESSAGES':
      return {
        ...state,
        messages: {
          ...state.messages,
          [action.payload.chatId]: action.payload.messages,
        },
      };
    case 'SET_STATUS_UPDATES':
      return { ...state, statusUpdates: action.payload };
    case 'SET_UNKNOWN_MESSAGES':
      return { ...state, unknownMessages: action.payload };
    case 'SET_CONNECTION_STATUS':
      return { ...state, connectionStatus: action.payload };
    case 'SET_THEME':
      return { ...state, theme: action.payload };
    case 'SET_LOADING':
      return { ...state, isLoading: action.payload };
    case 'SET_ERROR':
      return { ...state, error: action.payload };
    default:
      return state;
  }
}

const AppContext = createContext<{
  state: AppState;
  dispatch: React.Dispatch<AppAction>;
} | null>(null);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(appReducer, initialState);

  // Load theme from localStorage
  useEffect(() => {
    const savedTheme = localStorage.getItem('theme') as Theme;
    if (savedTheme) {
      dispatch({ type: 'SET_THEME', payload: savedTheme });
    }
  }, []);

  // Apply theme to document
  useEffect(() => {
    if (state.theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    localStorage.setItem('theme', state.theme);
  }, [state.theme]);

  return (
    <AppContext.Provider value={{ state, dispatch }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}
