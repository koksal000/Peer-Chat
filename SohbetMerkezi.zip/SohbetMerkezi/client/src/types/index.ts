export interface User {
  id: string;
  peerId: string;
  name: string;
  avatar?: string;
  status: string;
  isOnline: boolean;
  lastSeen: Date;
}

export interface Contact {
  id: string;
  userId: string;
  contactId: string;
  name: string;
  isBlocked: boolean;
}

export interface Group {
  id: string;
  name: string;
  description?: string;
  avatar?: string;
  createdBy: string;
  members: GroupMember[];
}

export interface GroupMember {
  id: string;
  groupId: string;
  userId: string;
  role: 'member' | 'admin';
  joinedAt: Date;
}

export interface Chat {
  id: string;
  type: 'individual' | 'group' | 'ai';
  participants: string[];
  lastMessage?: string;
  lastMessageTime?: Date;
  unreadCount?: number;
}

export interface Message {
  id: string;
  chatId: string;
  senderId: string;
  type: 'text' | 'image' | 'video' | 'document' | 'voice' | 'location';
  content: string;
  metadata?: any;
  replyTo?: string;
  isForwarded: boolean;
  isStarred: boolean;
  isDeleted: boolean;
  deliveredTo: string[];
  readBy: string[];
  timestamp: Date;
}

export interface StatusUpdate {
  id: string;
  userId: string;
  type: 'text' | 'image' | 'video';
  content: string;
  caption?: string;
  viewers: string[];
  privacy: 'contacts' | 'except' | 'only';
  expiresAt: Date;
  createdAt: Date;
}

export interface FileRecord {
  id: string;
  fileName: string;
  fileSize: number;
  mimeType: string;
  filePath: string;
  thumbnailPath?: string;
  uploadedBy: string;
}

export interface UnknownMessage {
  id: string;
  recipientId: string;
  senderPeerId: string;
  senderName?: string;
  content: string;
  type: string;
  isAccepted: boolean;
  createdAt: Date;
}

export interface AIResponse {
  content: string;
  type: 'text' | 'code' | 'error';
  metadata?: any;
}

export interface WSMessage {
  type: string;
  data: any;
  peerId?: string;
  timestamp: number;
}

export type ConnectionStatus = 'connecting' | 'connected' | 'disconnected' | 'error';

export type Theme = 'light' | 'dark';

export type TabType = 'chats' | 'status' | 'contacts' | 'groups';
