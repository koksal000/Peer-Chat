export interface User {
  id: string;
  username: string;
  peerId: string;
  name: string;
  avatar?: string;
  status?: string;
  isOnline: boolean;
  lastSeen: Date;
}

export interface Contact {
  id: string;
  userId: string;
  contactId: string;
  displayName?: string;
  isBlocked: boolean;
  user?: User;
}

export interface Chat {
  id: string;
  type: 'individual' | 'group' | 'ai';
  name?: string;
  description?: string;
  avatar?: string;
  createdBy?: string;
  participants?: User[];
  lastMessage?: Message;
  unreadCount?: number;
  updatedAt: Date;
}

export interface Message {
  id: string;
  chatId: string;
  senderId: string;
  type: 'text' | 'image' | 'video' | 'file' | 'audio' | 'location';
  content: string;
  metadata?: any;
  replyToId?: string;
  isEdited: boolean;
  isDeleted: boolean;
  timestamp: Date;
  status?: 'sent' | 'delivered' | 'read';
  sender?: User;
}

export interface StatusUpdate {
  id: string;
  userId: string;
  type: 'text' | 'image' | 'video';
  content: string;
  caption?: string;
  privacyLevel: 'contacts' | 'public' | 'custom';
  viewCount: number;
  createdAt: Date;
  expiresAt: Date;
  user?: User;
}

export interface FileUpload {
  id: string;
  filename: string;
  originalName: string;
  mimeType: string;
  size: number;
  filePath: string;
  uploadedBy: string;
}

export interface WSMessage {
  type: 'message' | 'typing' | 'status' | 'call' | 'notification' | 'register' | 'connected' | 'error';
  data: any;
  targetUser?: string;
  chatId?: string;
  userId?: string;
}

export interface TypingIndicator {
  userId: string;
  chatId: string;
  isTyping: boolean;
}
