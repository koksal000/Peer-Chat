import { useEffect, useRef, useState, useCallback } from 'react';
import { useApp } from '../context/AppContext';

interface PeerConnection {
  id: string;
  connection: any; // DataConnection from PeerJS
}

export function usePeer() {
  const { state, dispatch } = useApp();
  const peerRef = useRef<any>(null);
  const [connections, setConnections] = useState<Map<string, PeerConnection>>(new Map());
  const [isReady, setIsReady] = useState(false);

  const initializePeer = useCallback(async () => {
    try {
      // Import PeerJS dynamically
      const { Peer } = await import('peerjs');
      
      // Get or generate peer ID
      let peerId = localStorage.getItem('peerId');
      if (!peerId) {
        peerId = 'peer-' + Math.random().toString(36).substr(2, 9) + Math.random().toString(36).substr(2, 9);
        localStorage.setItem('peerId', peerId);
      }

      peerRef.current = new Peer(peerId, {
        debug: 2,
      });

      peerRef.current.on('open', (id: string) => {
        console.log('Peer connection opened with ID:', id);
        setIsReady(true);
        dispatch({ type: 'SET_CONNECTION_STATUS', payload: 'connected' });
      });

      peerRef.current.on('connection', (conn: any) => {
        console.log('Incoming peer connection:', conn.peer);
        setupConnection(conn);
      });

      peerRef.current.on('error', (error: any) => {
        console.error('Peer error:', error);
        dispatch({ type: 'SET_CONNECTION_STATUS', payload: 'error' });
      });

      peerRef.current.on('disconnected', () => {
        console.log('Peer disconnected');
        dispatch({ type: 'SET_CONNECTION_STATUS', payload: 'disconnected' });
      });

    } catch (error) {
      console.error('Failed to initialize peer:', error);
      dispatch({ type: 'SET_CONNECTION_STATUS', payload: 'error' });
    }
  }, [dispatch]);

  const setupConnection = useCallback((conn: any) => {
    conn.on('open', () => {
      console.log('Data connection opened with:', conn.peer);
      setConnections(prev => new Map(prev.set(conn.peer, { id: conn.peer, connection: conn })));
    });

    conn.on('data', (data: any) => {
      console.log('Received data from', conn.peer, ':', data);
      handleIncomingMessage(data, conn.peer);
    });

    conn.on('close', () => {
      console.log('Data connection closed with:', conn.peer);
      setConnections(prev => {
        const newMap = new Map(prev);
        newMap.delete(conn.peer);
        return newMap;
      });
    });

    conn.on('error', (error: any) => {
      console.error('Connection error with', conn.peer, ':', error);
    });
  }, []);

  const handleIncomingMessage = useCallback((data: any, peerId: string) => {
    switch (data.type) {
      case 'message':
        // Handle incoming message
        dispatch({
          type: 'ADD_MESSAGE',
          payload: {
            chatId: data.chatId,
            message: {
              ...data.message,
              id: crypto.randomUUID(),
              timestamp: new Date(),
            },
          },
        });
        break;
      
      case 'typing':
        // Handle typing indicator
        console.log(`${peerId} is typing...`);
        break;
      
      case 'delivery_receipt':
        // Handle delivery receipt
        console.log(`Message delivered to ${peerId}`);
        break;
      
      case 'read_receipt':
        // Handle read receipt
        console.log(`Message read by ${peerId}`);
        break;
      
      default:
        console.log('Unknown message type:', data.type);
    }
  }, [dispatch]);

  const connectToPeer = useCallback(async (peerId: string) => {
    if (!peerRef.current || !isReady) {
      throw new Error('Peer not ready');
    }

    try {
      const conn = peerRef.current.connect(peerId);
      setupConnection(conn);
      return conn;
    } catch (error) {
      console.error('Failed to connect to peer:', error);
      throw error;
    }
  }, [isReady, setupConnection]);

  const sendToPeer = useCallback((peerId: string, data: any) => {
    const connection = connections.get(peerId);
    if (connection?.connection.open) {
      connection.connection.send(data);
      return true;
    }
    return false;
  }, [connections]);

  const broadcastToConnections = useCallback((data: any) => {
    let sentCount = 0;
    connections.forEach((conn) => {
      if (conn.connection.open) {
        conn.connection.send(data);
        sentCount++;
      }
    });
    return sentCount;
  }, [connections]);

  const getPeerId = useCallback(() => {
    return peerRef.current?.id || localStorage.getItem('peerId');
  }, []);

  const getConnectedPeers = useCallback(() => {
    return Array.from(connections.keys());
  }, [connections]);

  useEffect(() => {
    initializePeer();

    return () => {
      if (peerRef.current) {
        peerRef.current.destroy();
      }
    };
  }, [initializePeer]);

  return {
    isReady,
    peerId: getPeerId(),
    connections: Array.from(connections.values()),
    connectToPeer,
    sendToPeer,
    broadcastToConnections,
    getConnectedPeers,
  };
}
