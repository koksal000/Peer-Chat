import { useState, useCallback } from 'react';
import { ALLOWED_FILE_TYPES, MAX_FILE_SIZE, MAX_FILES_COUNT } from '@/utils/constants';
import { useToast } from '@/hooks/use-toast';

interface FileUploadOptions {
  maxFiles?: number;
  maxFileSize?: number;
  allowedTypes?: string[];
  onSuccess?: (files: any[]) => void;
  onError?: (error: string) => void;
}

export function useFileUpload(options: FileUploadOptions = {}) {
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadedFiles, setUploadedFiles] = useState<any[]>([]);
  const { toast } = useToast();

  const {
    maxFiles = MAX_FILES_COUNT,
    maxFileSize = MAX_FILE_SIZE,
    allowedTypes = ALLOWED_FILE_TYPES,
    onSuccess,
    onError
  } = options;

  const validateFiles = useCallback((files: FileList): string | null => {
    if (files.length > maxFiles) {
      return `Maximum ${maxFiles} files allowed`;
    }

    for (const file of Array.from(files)) {
      if (file.size > maxFileSize) {
        return `File "${file.name}" is too large. Maximum size is ${formatFileSize(maxFileSize)}`;
      }

      if (!allowedTypes.includes(file.type)) {
        return `File type "${file.type}" is not allowed`;
      }
    }

    return null;
  }, [maxFiles, maxFileSize, allowedTypes]);

  const uploadFiles = useCallback(async (files: FileList, uploadedBy: string): Promise<any[]> => {
    const validationError = validateFiles(files);
    if (validationError) {
      onError?.(validationError);
      toast({
        title: "Upload Error",
        description: validationError,
        variant: "destructive",
      });
      throw new Error(validationError);
    }

    setIsUploading(true);
    setUploadProgress(0);

    try {
      const formData = new FormData();
      Array.from(files).forEach(file => {
        formData.append('files', file);
      });
      formData.append('uploadedBy', uploadedBy);

      const response = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Upload failed');
      }

      const uploadedFilesData = await response.json();
      setUploadedFiles(uploadedFilesData);
      onSuccess?.(uploadedFilesData);
      
      toast({
        title: "Upload Successful",
        description: `${uploadedFilesData.length} file(s) uploaded successfully`,
      });

      return uploadedFilesData;
    } catch (error: any) {
      onError?.(error.message);
      toast({
        title: "Upload Failed",
        description: error.message,
        variant: "destructive",
      });
      throw error;
    } finally {
      setIsUploading(false);
      setUploadProgress(0);
    }
  }, [validateFiles, onSuccess, onError, toast]);

  const uploadSingleFile = useCallback(async (file: File, uploadedBy: string) => {
    const fileList = new DataTransfer();
    fileList.items.add(file);
    return uploadFiles(fileList.files, uploadedBy);
  }, [uploadFiles]);

  const reset = useCallback(() => {
    setIsUploading(false);
    setUploadProgress(0);
    setUploadedFiles([]);
  }, []);

  return {
    isUploading,
    uploadProgress,
    uploadedFiles,
    uploadFiles,
    uploadSingleFile,
    validateFiles,
    reset
  };
}

function formatFileSize(bytes: number): string {
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  if (bytes === 0) return '0 Bytes';
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  return Math.round(bytes / Math.pow(1024, i) * 100) / 100 + ' ' + sizes[i];
}
