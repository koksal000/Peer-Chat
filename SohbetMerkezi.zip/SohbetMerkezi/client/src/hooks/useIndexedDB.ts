import { useEffect, useState } from 'react';

interface IndexedDBConfig {
  dbName: string;
  version: number;
  stores: {
    name: string;
    keyPath: string;
    indexes?: { name: string; keyPath: string; unique?: boolean }[];
  }[];
}

const DB_CONFIG: IndexedDBConfig = {
  dbName: 'WhatsAppCloneDB',
  version: 1,
  stores: [
    {
      name: 'users',
      keyPath: 'id',
      indexes: [
        { name: 'peerId', keyPath: 'peerId', unique: true },
        { name: 'username', keyPath: 'username', unique: true }
      ]
    },
    {
      name: 'chats',
      keyPath: 'id',
      indexes: [
        { name: 'type', keyPath: 'type' },
        { name: 'updatedAt', keyPath: 'updatedAt' }
      ]
    },
    {
      name: 'messages',
      keyPath: 'id',
      indexes: [
        { name: 'chatId', keyPath: 'chatId' },
        { name: 'timestamp', keyPath: 'timestamp' },
        { name: 'senderId', keyPath: 'senderId' }
      ]
    },
    {
      name: 'contacts',
      keyPath: 'id',
      indexes: [
        { name: 'userId', keyPath: 'userId' },
        { name: 'contactId', keyPath: 'contactId' }
      ]
    },
    {
      name: 'statusUpdates',
      keyPath: 'id',
      indexes: [
        { name: 'userId', keyPath: 'userId' },
        { name: 'createdAt', keyPath: 'createdAt' },
        { name: 'expiresAt', keyPath: 'expiresAt' }
      ]
    },
    {
      name: 'files',
      keyPath: 'id',
      indexes: [
        { name: 'uploadedBy', keyPath: 'uploadedBy' },
        { name: 'uploadedAt', keyPath: 'uploadedAt' }
      ]
    }
  ]
};

export function useIndexedDB() {
  const [db, setDb] = useState<IDBDatabase | null>(null);
  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    const openDB = () => {
      const request = indexedDB.open(DB_CONFIG.dbName, DB_CONFIG.version);

      request.onerror = () => {
        console.error('Failed to open IndexedDB:', request.error);
      };

      request.onsuccess = () => {
        setDb(request.result);
        setIsReady(true);
      };

      request.onupgradeneeded = (event) => {
        const database = (event.target as IDBOpenDBRequest).result;

        DB_CONFIG.stores.forEach(store => {
          if (!database.objectStoreNames.contains(store.name)) {
            const objectStore = database.createObjectStore(store.name, { 
              keyPath: store.keyPath 
            });

            store.indexes?.forEach(index => {
              objectStore.createIndex(index.name, index.keyPath, { 
                unique: index.unique || false 
              });
            });
          }
        });
      };
    };

    openDB();
  }, []);

  const add = async <T>(storeName: string, data: T): Promise<T> => {
    if (!db) throw new Error('Database not initialized');

    return new Promise((resolve, reject) => {
      const transaction = db.transaction([storeName], 'readwrite');
      const store = transaction.objectStore(storeName);
      const request = store.add(data);

      request.onsuccess = () => resolve(data);
      request.onerror = () => reject(request.error);
    });
  };

  const get = async <T>(storeName: string, key: string): Promise<T | undefined> => {
    if (!db) throw new Error('Database not initialized');

    return new Promise((resolve, reject) => {
      const transaction = db.transaction([storeName], 'readonly');
      const store = transaction.objectStore(storeName);
      const request = store.get(key);

      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  };

  const getAll = async <T>(storeName: string): Promise<T[]> => {
    if (!db) throw new Error('Database not initialized');

    return new Promise((resolve, reject) => {
      const transaction = db.transaction([storeName], 'readonly');
      const store = transaction.objectStore(storeName);
      const request = store.getAll();

      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  };

  const getByIndex = async <T>(
    storeName: string, 
    indexName: string, 
    value: any
  ): Promise<T[]> => {
    if (!db) throw new Error('Database not initialized');

    return new Promise((resolve, reject) => {
      const transaction = db.transaction([storeName], 'readonly');
      const store = transaction.objectStore(storeName);
      const index = store.index(indexName);
      const request = index.getAll(value);

      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  };

  const update = async <T>(storeName: string, data: T): Promise<T> => {
    if (!db) throw new Error('Database not initialized');

    return new Promise((resolve, reject) => {
      const transaction = db.transaction([storeName], 'readwrite');
      const store = transaction.objectStore(storeName);
      const request = store.put(data);

      request.onsuccess = () => resolve(data);
      request.onerror = () => reject(request.error);
    });
  };

  const remove = async (storeName: string, key: string): Promise<void> => {
    if (!db) throw new Error('Database not initialized');

    return new Promise((resolve, reject) => {
      const transaction = db.transaction([storeName], 'readwrite');
      const store = transaction.objectStore(storeName);
      const request = store.delete(key);

      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  };

  const clear = async (storeName: string): Promise<void> => {
    if (!db) throw new Error('Database not initialized');

    return new Promise((resolve, reject) => {
      const transaction = db.transaction([storeName], 'readwrite');
      const store = transaction.objectStore(storeName);
      const request = store.clear();

      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  };

  return {
    isReady,
    add,
    get,
    getAll,
    getByIndex,
    update,
    remove,
    clear
  };
}
