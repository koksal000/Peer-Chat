import { FileRecord } from '../types';

export interface FileUploadResult {
  file: FileRecord;
  url: string;
}

class FileService {
  private baseUrl = '/api';

  async uploadFile(file: File, userId: string, messageId?: string, statusId?: string): Promise<FileUploadResult> {
    try {
      const formData = new FormData();
      formData.append('file', file);
      formData.append('userId', userId);
      if (messageId) formData.append('messageId', messageId);
      if (statusId) formData.append('statusId', statusId);

      const response = await fetch(`${this.baseUrl}/upload`, {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        throw new Error(`Upload failed: ${response.statusText}`);
      }

      const fileRecord: FileRecord = await response.json();
      const url = `${this.baseUrl}/files/${fileRecord.id}`;

      return { file: fileRecord, url };
    } catch (error) {
      console.error('File upload error:', error);
      throw error;
    }
  }

  async downloadFile(fileId: string): Promise<Blob> {
    try {
      const response = await fetch(`${this.baseUrl}/files/${fileId}`);
      
      if (!response.ok) {
        throw new Error(`Download failed: ${response.statusText}`);
      }

      return await response.blob();
    } catch (error) {
      console.error('File download error:', error);
      throw error;
    }
  }

  getFileUrl(fileId: string): string {
    return `${this.baseUrl}/files/${fileId}`;
  }

  formatFileSize(bytes: number): string {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  }

  getFileIcon(mimeType: string): string {
    if (mimeType.startsWith('image/')) return 'fas fa-image';
    if (mimeType.startsWith('video/')) return 'fas fa-video';
    if (mimeType.startsWith('audio/')) return 'fas fa-music';
    if (mimeType.includes('pdf')) return 'fas fa-file-pdf';
    if (mimeType.includes('word')) return 'fas fa-file-word';
    if (mimeType.includes('excel')) return 'fas fa-file-excel';
    if (mimeType.includes('powerpoint')) return 'fas fa-file-powerpoint';
    if (mimeType.includes('zip') || mimeType.includes('rar')) return 'fas fa-file-archive';
    return 'fas fa-file';
  }

  isImageFile(mimeType: string): boolean {
    return mimeType.startsWith('image/');
  }

  isVideoFile(mimeType: string): boolean {
    return mimeType.startsWith('video/');
  }

  isAudioFile(mimeType: string): boolean {
    return mimeType.startsWith('audio/');
  }

  async createThumbnail(file: File): Promise<string | null> {
    if (!this.isImageFile(file.type) && !this.isVideoFile(file.type)) {
      return null;
    }

    return new Promise((resolve) => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      
      if (this.isImageFile(file.type)) {
        const img = new Image();
        img.onload = () => {
          const maxSize = 150;
          const ratio = Math.min(maxSize / img.width, maxSize / img.height);
          
          canvas.width = img.width * ratio;
          canvas.height = img.height * ratio;
          
          ctx?.drawImage(img, 0, 0, canvas.width, canvas.height);
          resolve(canvas.toDataURL('image/jpeg', 0.7));
        };
        img.onerror = () => resolve(null);
        img.src = URL.createObjectURL(file);
      } else {
        // For videos, we'd need a video element to capture a frame
        resolve(null);
      }
    });
  }
}

export const fileService = new FileService();
