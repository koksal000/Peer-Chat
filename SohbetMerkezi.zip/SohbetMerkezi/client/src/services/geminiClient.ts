import { AIResponse } from '../types';

class GeminiClient {
  private baseUrl = '/api/ai';

  async sendMessage(message: string, context?: string): Promise<AIResponse> {
    try {
      const response = await fetch(`${this.baseUrl}/chat`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ message, context }),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Gemini API error:', error);
      return {
        content: "I'm sorry, I'm having trouble connecting right now. Please try again later.",
        type: 'error',
        metadata: { error: error.message },
      };
    }
  }

  async analyzeImage(imageFile: File, prompt?: string): Promise<AIResponse> {
    try {
      const formData = new FormData();
      formData.append('image', imageFile);
      if (prompt) {
        formData.append('prompt', prompt);
      }

      const response = await fetch(`${this.baseUrl}/analyze-image`, {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Image analysis error:', error);
      return {
        content: "I couldn't analyze this image. Please try again.",
        type: 'error',
        metadata: { error: error.message },
      };
    }
  }

  async generateCode(problem: string, language: string = 'javascript'): Promise<AIResponse> {
    try {
      const response = await fetch(`${this.baseUrl}/code`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ problem, language }),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Code generation error:', error);
      return {
        content: "I couldn't generate code for this problem. Please try again.",
        type: 'error',
        metadata: { error: error.message },
      };
    }
  }
}

export const geminiClient = new GeminiClient();
