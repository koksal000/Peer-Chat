import { Message } from '../types';

export interface PeerMessage {
  type: 'message' | 'typing' | 'delivery_receipt' | 'read_receipt' | 'file';
  chatId: string;
  message?: Message;
  data?: any;
  timestamp: number;
}

class PeerService {
  private connections: Map<string, any> = new Map();
  private messageQueue: Map<string, PeerMessage[]> = new Map();

  async sendMessageToPeer(peerId: string, message: PeerMessage): Promise<boolean> {
    const connection = this.connections.get(peerId);
    
    if (connection && connection.open) {
      try {
        connection.send(message);
        return true;
      } catch (error) {
        console.error('Failed to send message to peer:', error);
        // Queue message for later
        this.queueMessage(peerId, message);
        return false;
      }
    } else {
      // Queue message for when connection is established
      this.queueMessage(peerId, message);
      return false;
    }
  }

  private queueMessage(peerId: string, message: PeerMessage) {
    if (!this.messageQueue.has(peerId)) {
      this.messageQueue.set(peerId, []);
    }
    this.messageQueue.get(peerId)!.push(message);
  }

  async sendDeliveryReceipt(peerId: string, messageId: string, chatId: string) {
    const receipt: PeerMessage = {
      type: 'delivery_receipt',
      chatId,
      data: { messageId },
      timestamp: Date.now(),
    };
    
    return this.sendMessageToPeer(peerId, receipt);
  }

  async sendReadReceipt(peerId: string, messageId: string, chatId: string) {
    const receipt: PeerMessage = {
      type: 'read_receipt',
      chatId,
      data: { messageId },
      timestamp: Date.now(),
    };
    
    return this.sendMessageToPeer(peerId, receipt);
  }

  async sendTypingIndicator(peerId: string, chatId: string, isTyping: boolean) {
    const indicator: PeerMessage = {
      type: 'typing',
      chatId,
      data: { isTyping },
      timestamp: Date.now(),
    };
    
    return this.sendMessageToPeer(peerId, indicator);
  }

  async sendFileMessage(peerId: string, chatId: string, fileData: ArrayBuffer, metadata: any) {
    const fileMessage: PeerMessage = {
      type: 'file',
      chatId,
      data: { fileData, metadata },
      timestamp: Date.now(),
    };
    
    return this.sendMessageToPeer(peerId, fileMessage);
  }

  addConnection(peerId: string, connection: any) {
    this.connections.set(peerId, connection);
    
    // Send queued messages
    const queuedMessages = this.messageQueue.get(peerId);
    if (queuedMessages && queuedMessages.length > 0) {
      queuedMessages.forEach(message => {
        this.sendMessageToPeer(peerId, message);
      });
      this.messageQueue.delete(peerId);
    }
  }

  removeConnection(peerId: string) {
    this.connections.delete(peerId);
  }

  getConnection(peerId: string) {
    return this.connections.get(peerId);
  }

  isConnected(peerId: string): boolean {
    const connection = this.connections.get(peerId);
    return connection && connection.open;
  }

  getConnectedPeers(): string[] {
    return Array.from(this.connections.keys()).filter(peerId => 
      this.isConnected(peerId)
    );
  }
}

export const peerService = new PeerService();
