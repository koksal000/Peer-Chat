import React from 'react';
import { useApp } from '../context/AppContext';
import MessageList from './MessageList';
import MessageInput from './MessageInput';
import { Phone, Video, Search, MoreVertical, ArrowLeft } from 'lucide-react';

export default function ChatArea() {
  const { state, dispatch } = useApp();

  if (!state.activeChat) {
    return (
      <div className="flex-1 flex items-center justify-center bg-gray-50 dark:bg-gray-900">
        <div className="text-center max-w-md mx-auto">
          <div className="w-32 h-32 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center mx-auto mb-6">
            <i className="fas fa-comments text-6xl text-green-600 dark:text-green-400"></i>
          </div>
          <h2 className="text-2xl font-semibold text-gray-800 dark:text-gray-200 mb-2">
            WhatsApp Clone Web
          </h2>
          <p className="text-gray-600 dark:text-gray-400 mb-4">
            Send and receive messages without keeping your phone online.
          </p>
          <p className="text-sm text-gray-500 dark:text-gray-500 mb-8">
            Use WhatsApp Clone on up to 4 linked devices and 1 phone
          </p>
          
          {state.currentUser && (
            <div className="bg-white dark:bg-gray-800 rounded-lg p-4 shadow-sm">
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">Your Peer ID:</p>
              <div className="flex items-center justify-center space-x-2">
                <code className="bg-gray-100 dark:bg-gray-700 px-3 py-2 rounded font-mono text-sm">
                  {state.currentUser.peerId}
                </code>
                <button
                  onClick={() => navigator.clipboard.writeText(state.currentUser?.peerId || '')}
                  className="text-green-600 hover:text-green-700 dark:text-green-400 dark:hover:text-green-300"
                  data-testid="button-copy-peer-id"
                >
                  <i className="fas fa-copy"></i>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  const getChatInfo = () => {
    if (state.activeChat === 'ai-assistant') {
      return {
        name: 'Gemini AI Assistant',
        status: 'Online • AI-powered responses',
        avatar: null,
        isAI: true,
      };
    }
    
    const chat = state.chats.find(c => c.id === state.activeChat);
    return {
      name: chat?.type === 'group' ? `Group ${chat.id.slice(-4)}` : `User ${chat?.participants[0]?.slice(-4)}`,
      status: 'Last seen recently',
      avatar: null,
      isAI: false,
    };
  };

  const chatInfo = getChatInfo();

  return (
    <div className="flex-1 flex flex-col bg-gray-50 dark:bg-gray-900">
      {/* Chat Header */}
      <div className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <button
              onClick={() => dispatch({ type: 'SET_ACTIVE_CHAT', payload: null })}
              className="md:hidden text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200"
              data-testid="button-back"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            
            <div className="relative">
              {chatInfo.isAI ? (
                <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center">
                  <i className="fas fa-robot text-white"></i>
                </div>
              ) : (
                <div className="w-10 h-10 bg-gray-300 dark:bg-gray-600 rounded-full flex items-center justify-center">
                  <span className="text-gray-600 dark:text-gray-300 font-medium">
                    {chatInfo.name.charAt(0)}
                  </span>
                </div>
              )}
              <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-green-500 border-2 border-white rounded-full"></div>
            </div>
            
            <div>
              <h3 className="font-medium text-gray-900 dark:text-white">
                {chatInfo.name}
              </h3>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                {chatInfo.status}
              </p>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <button
              className="p-2 text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full transition-colors"
              data-testid="button-video-call"
            >
              <Video className="w-5 h-5" />
            </button>
            <button
              className="p-2 text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full transition-colors"
              data-testid="button-voice-call"
            >
              <Phone className="w-5 h-5" />
            </button>
            <button
              className="p-2 text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full transition-colors"
              data-testid="button-search-in-chat"
            >
              <Search className="w-5 h-5" />
            </button>
            <button
              className="p-2 text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full transition-colors"
              data-testid="button-chat-menu"
            >
              <MoreVertical className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Messages Area */}
      <div className="flex-1 overflow-hidden">
        <MessageList chatId={state.activeChat} />
      </div>

      {/* Message Input */}
      <MessageInput chatId={state.activeChat} />
    </div>
  );
}
