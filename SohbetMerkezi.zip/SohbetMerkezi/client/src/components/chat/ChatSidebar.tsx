import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  MessageCircle, 
  Plus, 
  Settings, 
  Search, 
  Users, 
  CircleDot, 
  Moon, 
  Sun,
  AlertTriangle,
  UserRound
} from 'lucide-react';
import { Chat, Contact, StatusUpdate, UnknownMessage, User } from '@/types/chat';

interface ChatSidebarProps {
  currentUser: User;
  chats: Chat[];
  contacts: Contact[];
  statuses: StatusUpdate[];
  unknownMessages: UnknownMessage[];
  activeChat: string | null;
  activeTab: string;
  searchQuery: string;
  onChatSelect: (chatId: string) => void;
  onTabChange: (tab: string) => void;
  onSearchChange: (query: string) => void;
  onNewChat: () => void;
  onNewGroup: () => void;
  onAddContact: () => void;
  onAddStatus: () => void;
  onSettings: () => void;
  onToggleTheme: () => void;
  onUnknownMessage: (messageId: string) => void;
  isDarkMode: boolean;
}

export function ChatSidebar({
  currentUser,
  chats,
  contacts,
  statuses,
  unknownMessages,
  activeChat,
  activeTab,
  searchQuery,
  onChatSelect,
  onTabChange,
  onSearchChange,
  onNewChat,
  onNewGroup,
  onAddContact,
  onAddStatus,
  onSettings,
  onToggleTheme,
  onUnknownMessage,
  isDarkMode
}: ChatSidebarProps) {
  const [filteredChats, setFilteredChats] = useState<Chat[]>(chats);

  useEffect(() => {
    if (!searchQuery) {
      setFilteredChats(chats);
    } else {
      const filtered = chats.filter(chat => 
        chat.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        chat.lastMessage?.content.toLowerCase().includes(searchQuery.toLowerCase())
      );
      setFilteredChats(filtered);
    }
  }, [chats, searchQuery]);

  const formatTime = (date: Date) => {
    const now = new Date();
    const messageDate = new Date(date);
    const diffInHours = (now.getTime() - messageDate.getTime()) / (1000 * 60 * 60);

    if (diffInHours < 1) {
      return messageDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } else if (diffInHours < 24) {
      return messageDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } else if (diffInHours < 168) { // Less than a week
      return messageDate.toLocaleDateString([], { weekday: 'short' });
    } else {
      return messageDate.toLocaleDateString([], { month: 'short', day: 'numeric' });
    }
  };

  return (
    <div className="w-80 bg-background border-r border-border flex flex-col h-full">
      {/* Header */}
      <div className="p-4 bg-whatsapp-teal text-white">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <Avatar className="h-10 w-10">
              <AvatarImage src={currentUser.profilePicture || undefined} />
              <AvatarFallback>{currentUser.displayName[0]}</AvatarFallback>
            </Avatar>
            <div>
              <h2 className="font-medium text-sm">{currentUser.displayName}</h2>
              <p className="text-xs text-teal-100">{currentUser.status}</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <Button
              variant="ghost"
              size="sm"
              className="text-white hover:bg-white/10"
              onClick={onAddStatus}
              data-testid="add-status-btn"
            >
              <Plus className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="text-white hover:bg-white/10"
              onClick={onNewChat}
              data-testid="new-chat-btn"
            >
              <MessageCircle className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="text-white hover:bg-white/10"
              onClick={onToggleTheme}
              data-testid="theme-toggle-btn"
            >
              {isDarkMode ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="text-white hover:bg-white/10"
              onClick={onSettings}
              data-testid="settings-btn"
            >
              <Settings className="h-4 w-4" />
            </Button>
          </div>
        </div>
        
        {/* Search Bar */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-teal-100" />
          <Input
            placeholder="Search or start new chat"
            className="pl-10 bg-white/20 border-none text-white placeholder-teal-100 focus:bg-white/30"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            data-testid="search-input"
          />
        </div>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={onTabChange} className="flex-1 flex flex-col">
        <TabsList className="bg-whatsapp-teal text-white rounded-none">
          <TabsTrigger value="chats" className="flex-1 text-white data-[state=active]:bg-white/20">
            <MessageCircle className="h-4 w-4 mr-2" />
            Chats
            {chats.reduce((acc, chat) => acc + (chat.unreadCount || 0), 0) > 0 && (
              <Badge variant="destructive" className="ml-2">
                {chats.reduce((acc, chat) => acc + (chat.unreadCount || 0), 0)}
              </Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="status" className="flex-1 text-white data-[state=active]:bg-white/20">
            <CircleDot className="h-4 w-4 mr-2" />
            Status
          </TabsTrigger>
          <TabsTrigger value="contacts" className="flex-1 text-white data-[state=active]:bg-white/20">
            <Users className="h-4 w-4 mr-2" />
            People
          </TabsTrigger>
        </TabsList>

        {/* Chat Tab */}
        <TabsContent value="chats" className="flex-1 flex flex-col m-0">
          <ScrollArea className="flex-1">
            {/* Unknown Messages */}
            {unknownMessages.length > 0 && (
              <div className="p-3 bg-yellow-50 dark:bg-yellow-900/20 border-b">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <AlertTriangle className="h-4 w-4 text-yellow-600 dark:text-yellow-400" />
                    <span className="text-sm font-medium">Unknown Messages</span>
                    <Badge variant="secondary">{unknownMessages.length}</Badge>
                  </div>
                </div>
                
                <div className="mt-2 space-y-2">
                  {unknownMessages.slice(0, 3).map((message) => (
                    <div
                      key={message.id}
                      className="flex items-center p-2 hover:bg-yellow-100 dark:hover:bg-yellow-900/30 rounded cursor-pointer"
                      onClick={() => onUnknownMessage(message.id)}
                      data-testid={`unknown-message-${message.id}`}
                    >
                      <UserRound className="h-8 w-8 text-gray-400 mr-3" />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <h4 className="font-medium text-sm truncate">
                            {message.senderName || 'Unknown Contact'}
                          </h4>
                          <span className="text-xs text-gray-500">
                            {formatTime(message.timestamp)}
                          </span>
                        </div>
                        <p className="text-sm text-gray-600 dark:text-gray-300 truncate">
                          {message.content}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Chat List */}
            <div className="divide-y divide-border">
              {filteredChats.map((chat) => (
                <div
                  key={chat.id}
                  className={`p-3 hover:bg-accent cursor-pointer transition-colors ${
                    activeChat === chat.id ? 'bg-accent border-l-4 border-whatsapp-teal' : ''
                  }`}
                  onClick={() => onChatSelect(chat.id)}
                  data-testid={`chat-item-${chat.id}`}
                >
                  <div className="flex items-center space-x-3">
                    <div className="relative">
                      <Avatar className="h-12 w-12">
                        <AvatarImage src={chat.profilePicture || undefined} />
                        <AvatarFallback>
                          {chat.type === 'group' ? (
                            <Users className="h-6 w-6" />
                          ) : (
                            chat.name?.[0] || '?'
                          )}
                        </AvatarFallback>
                      </Avatar>
                      {chat.type === 'direct' && (
                        <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-green-500 border-2 border-background rounded-full" />
                      )}
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <h3 className="font-medium truncate">{chat.name}</h3>
                        <span className="text-xs text-muted-foreground">
                          {chat.lastMessage && formatTime(chat.lastMessage.timestamp)}
                        </span>
                      </div>
                      <div className="flex items-center justify-between mt-1">
                        <p className="text-sm text-muted-foreground truncate">
                          {chat.lastMessage?.content || 'No messages yet'}
                        </p>
                        {chat.unreadCount && chat.unreadCount > 0 && (
                          <Badge className="bg-whatsapp-green text-white">
                            {chat.unreadCount}
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>
        </TabsContent>

        {/* Status Tab */}
        <TabsContent value="status" className="flex-1 flex flex-col m-0">
          <ScrollArea className="flex-1">
            <div className="p-4">
              {/* My Status */}
              <div
                className="flex items-center p-3 hover:bg-accent rounded-lg cursor-pointer"
                onClick={onAddStatus}
                data-testid="my-status-btn"
              >
                <div className="relative">
                  <Avatar className="h-12 w-12 border-2 border-dashed border-gray-400">
                    <AvatarImage src={currentUser.profilePicture || undefined} />
                    <AvatarFallback>{currentUser.displayName[0]}</AvatarFallback>
                  </Avatar>
                  <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-whatsapp-green rounded-full flex items-center justify-center">
                    <Plus className="h-2 w-2 text-white" />
                  </div>
                </div>
                <div className="ml-3">
                  <h3 className="font-medium">My Status</h3>
                  <p className="text-sm text-muted-foreground">Tap to add status update</p>
                </div>
              </div>

              {/* Recent Updates */}
              {statuses.length > 0 && (
                <div className="mt-4">
                  <h4 className="text-sm font-medium text-muted-foreground mb-3 uppercase tracking-wide">
                    Recent updates
                  </h4>
                  <div className="space-y-2">
                    {statuses.map((status) => (
                      <div
                        key={status.id}
                        className="flex items-center p-3 hover:bg-accent rounded-lg cursor-pointer"
                        data-testid={`status-item-${status.id}`}
                      >
                        <div className="relative">
                          <Avatar className="h-12 w-12 border-2 border-whatsapp-green p-0.5">
                            <AvatarImage src={status.user?.profilePicture || undefined} />
                            <AvatarFallback>{status.user?.displayName[0] || 'U'}</AvatarFallback>
                          </Avatar>
                        </div>
                        <div className="ml-3">
                          <h3 className="font-medium">{status.user?.displayName}</h3>
                          <p className="text-sm text-muted-foreground">
                            {formatTime(status.createdAt)}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </ScrollArea>
        </TabsContent>

        {/* Contacts Tab */}
        <TabsContent value="contacts" className="flex-1 flex flex-col m-0">
          <div className="p-4 border-b">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold">Contacts</h3>
              <Button
                size="sm"
                className="bg-whatsapp-teal hover:bg-whatsapp-teal/90"
                onClick={onAddContact}
                data-testid="add-contact-btn"
              >
                <Plus className="h-4 w-4" />
              </Button>
            </div>
          </div>
          
          <ScrollArea className="flex-1">
            <div className="p-4 space-y-2">
              {contacts.map((contact) => (
                <div
                  key={contact.id}
                  className="flex items-center p-3 hover:bg-accent rounded-lg cursor-pointer"
                  data-testid={`contact-item-${contact.id}`}
                >
                  <Avatar className="h-10 w-10">
                    <AvatarImage src={contact.user?.profilePicture || undefined} />
                    <AvatarFallback>{contact.user?.displayName[0] || 'C'}</AvatarFallback>
                  </Avatar>
                  <div className="ml-3 flex-1">
                    <h3 className="font-medium">{contact.displayName || contact.user?.displayName}</h3>
                    <p className="text-sm text-muted-foreground">
                      {contact.user?.status || 'Hey there! I am using WhatsApp Clone'}
                    </p>
                  </div>
                  <div className="flex space-x-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-whatsapp-teal hover:text-whatsapp-teal/80"
                      onClick={() => onChatSelect(contact.id)}
                      data-testid={`chat-contact-${contact.id}`}
                    >
                      <MessageCircle className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>
        </TabsContent>
      </Tabs>

      {/* Floating Action Button */}
      <div className="absolute bottom-6 right-6">
        <Button
          className="w-14 h-14 rounded-full bg-whatsapp-green hover:bg-whatsapp-green/90 shadow-lg"
          onClick={activeTab === 'contacts' ? onAddContact : onNewChat}
          data-testid="fab-button"
        >
          <Plus className="h-6 w-6" />
        </Button>
      </div>
    </div>
  );
}
