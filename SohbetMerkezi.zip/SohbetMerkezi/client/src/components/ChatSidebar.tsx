import { useState } from 'react';
import { useChatContext } from '@/contexts/ChatContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Chat, Contact, StatusUpdate } from '@/types/chat';
import { cn } from '@/lib/utils';
import { formatDistanceToNow } from 'date-fns';

interface ChatSidebarProps {
  onShowStatus: () => void;
  onShowGroup: () => void;
  onShowContact: () => void;
}

export default function ChatSidebar({ onShowStatus, onShowGroup, onShowContact }: ChatSidebarProps) {
  const { state, setActiveChat } = useChatContext();
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState('chats');
  const [showUnknownMessages, setShowUnknownMessages] = useState(false);

  const filteredChats = state.chats.filter(chat => 
    chat.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    chat.description?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredContacts = state.contacts.filter(contact =>
    contact.displayName?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    contact.user?.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleChatClick = async (chat: Chat) => {
    setActiveChat(chat);
    
    // Load messages for this chat
    try {
      const response = await fetch(`/api/messages/${chat.id}`);
      if (response.ok) {
        const messages = await response.json();
        state.dispatch({ 
          type: 'SET_MESSAGES', 
          payload: { chatId: chat.id, messages } 
        });
      }
    } catch (error) {
      console.error('Failed to load messages:', error);
    }
  };

  const getLastMessagePreview = (chat: Chat) => {
    const messages = state.messages[chat.id];
    if (!messages || messages.length === 0) return 'No messages yet';
    
    const lastMessage = messages[messages.length - 1];
    if (lastMessage.type === 'text') {
      return lastMessage.content;
    }
    
    const typeIcon = {
      image: '🖼️',
      video: '🎥',
      file: '📎',
      audio: '🎵'
    }[lastMessage.type] || '📎';
    
    return `${typeIcon} ${lastMessage.type}`;
  };

  const getUnreadCount = (chatId: string) => {
    // This would be calculated based on message read status
    return Math.floor(Math.random() * 5); // Mock for now
  };

  return (
    <div className="w-80 bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 flex flex-col">
      {/* Header */}
      <div className="p-4 bg-teal-600 text-white">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <Avatar className="w-10 h-10" data-testid="user-avatar">
              <AvatarImage src={state.currentUser?.avatar} />
              <AvatarFallback className="bg-teal-700">
                {state.currentUser?.name.charAt(0)}
              </AvatarFallback>
            </Avatar>
            <div>
              <h2 className="font-medium text-sm" data-testid="user-name">
                {state.currentUser?.name || 'User'}
              </h2>
              <p className="text-xs opacity-80" data-testid="user-status">
                {state.currentUser?.status || 'Available'}
              </p>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <Button 
              variant="ghost" 
              size="sm" 
              className="text-white hover:bg-white/20"
              onClick={onShowStatus}
              data-testid="button-status"
            >
              <i className="fas fa-plus-circle" />
            </Button>
            <Button 
              variant="ghost" 
              size="sm" 
              className="text-white hover:bg-white/20"
              onClick={onShowContact}
              data-testid="button-new-chat"
            >
              <i className="fas fa-comment" />
            </Button>
            <Button 
              variant="ghost" 
              size="sm" 
              className="text-white hover:bg-white/20"
              data-testid="button-menu"
            >
              <i className="fas fa-ellipsis-vertical" />
            </Button>
          </div>
        </div>

        {/* Search */}
        <div className="relative">
          <Input
            placeholder="Search or start new chat"
            className="bg-white/20 border-none text-white placeholder-white/60 pl-10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            data-testid="input-search"
          />
          <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-white/60" />
        </div>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
        <TabsList className="grid w-full grid-cols-4 bg-teal-600 text-white rounded-none">
          <TabsTrigger 
            value="chats" 
            className="data-[state=active]:bg-white data-[state=active]:text-teal-600"
            data-testid="tab-chats"
          >
            <i className="fas fa-comment mr-2" />
            Chats
          </TabsTrigger>
          <TabsTrigger 
            value="status" 
            className="data-[state=active]:bg-white data-[state=active]:text-teal-600"
            data-testid="tab-status"
          >
            <i className="fas fa-circle-dot mr-2" />
            Status
          </TabsTrigger>
          <TabsTrigger 
            value="contacts" 
            className="data-[state=active]:bg-white data-[state=active]:text-teal-600"
            data-testid="tab-contacts"
          >
            <i className="fas fa-address-book mr-2" />
            People
          </TabsTrigger>
          <TabsTrigger 
            value="groups" 
            className="data-[state=active]:bg-white data-[state=active]:text-teal-600"
            data-testid="tab-groups"
          >
            <i className="fas fa-users mr-2" />
            Groups
          </TabsTrigger>
        </TabsList>

        <div className="flex-1 overflow-hidden">
          <TabsContent value="chats" className="h-full">
            <ScrollArea className="h-full">
              {/* Unknown Messages */}
              {state.unknownMessages.length > 0 && (
                <div className="border-b border-gray-200 dark:border-gray-700">
                  <div 
                    className="p-3 bg-yellow-50 dark:bg-yellow-900/20 cursor-pointer hover:bg-yellow-100 dark:hover:bg-yellow-900/30"
                    onClick={() => setShowUnknownMessages(!showUnknownMessages)}
                    data-testid="unknown-messages-header"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <i className="fas fa-exclamation-triangle text-yellow-600" />
                        <span className="text-sm font-medium text-yellow-800 dark:text-yellow-200">
                          Unknown Messages
                        </span>
                        <Badge variant="secondary" className="bg-yellow-200 text-yellow-800">
                          {state.unknownMessages.length}
                        </Badge>
                      </div>
                      <i className={`fas fa-chevron-${showUnknownMessages ? 'up' : 'down'} text-yellow-600`} />
                    </div>
                  </div>
                  
                  {showUnknownMessages && (
                    <div className="divide-y divide-gray-200 dark:divide-gray-700">
                      {state.unknownMessages.map((message) => (
                        <div 
                          key={message.id}
                          className="p-3 hover:bg-gray-50 dark:hover:bg-gray-700 cursor-pointer"
                          data-testid={`unknown-message-${message.id}`}
                        >
                          <div className="flex items-center space-x-3">
                            <Avatar className="w-12 h-12">
                              <AvatarFallback className="bg-gray-400">
                                <i className="fas fa-user-question text-white" />
                              </AvatarFallback>
                            </Avatar>
                            <div className="flex-1">
                              <div className="flex items-center justify-between">
                                <h3 className="font-medium text-gray-900 dark:text-white">
                                  Unknown Contact
                                </h3>
                                <span className="text-xs text-gray-500">
                                  {formatDistanceToNow(message.timestamp, { addSuffix: true })}
                                </span>
                              </div>
                              <p className="text-sm text-gray-600 dark:text-gray-300 truncate">
                                {message.content}
                              </p>
                            </div>
                            <Badge variant="destructive">New</Badge>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* Chats List */}
              <div className="divide-y divide-gray-200 dark:divide-gray-700">
                {filteredChats.map((chat) => {
                  const unreadCount = getUnreadCount(chat.id);
                  const isActive = state.activeChat?.id === chat.id;
                  
                  return (
                    <div
                      key={chat.id}
                      className={cn(
                        "p-3 hover:bg-gray-50 dark:hover:bg-gray-700 cursor-pointer transition-colors",
                        isActive && "bg-green-50 dark:bg-green-900/20 border-l-4 border-green-500"
                      )}
                      onClick={() => handleChatClick(chat)}
                      data-testid={`chat-item-${chat.id}`}
                    >
                      <div className="flex items-center space-x-3">
                        <div className="relative">
                          <Avatar className="w-12 h-12">
                            <AvatarImage src={chat.avatar} />
                            <AvatarFallback className={cn(
                              chat.type === 'ai' && "bg-gradient-to-r from-purple-500 to-blue-500 text-white"
                            )}>
                              {chat.type === 'ai' ? (
                                <i className="fas fa-robot" />
                              ) : chat.type === 'group' ? (
                                <i className="fas fa-users" />
                              ) : (
                                chat.name?.charAt(0)
                              )}
                            </AvatarFallback>
                          </Avatar>
                          {chat.type !== 'ai' && (
                            <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-green-400 border-2 border-white rounded-full" />
                          )}
                        </div>
                        
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between">
                            <h3 className="font-medium text-gray-900 dark:text-white truncate flex items-center">
                              {chat.name}
                              {chat.type === 'ai' && (
                                <Badge className="ml-2 bg-gradient-to-r from-purple-500 to-blue-500 text-white">
                                  AI
                                </Badge>
                              )}
                            </h3>
                            <span className="text-xs text-gray-500">
                              {formatDistanceToNow(chat.updatedAt, { addSuffix: true })}
                            </span>
                          </div>
                          
                          <div className="flex items-center justify-between">
                            <p className="text-sm text-gray-600 dark:text-gray-300 truncate">
                              {getLastMessagePreview(chat)}
                            </p>
                            {unreadCount > 0 && (
                              <Badge className="bg-green-500 text-white ml-2">
                                {unreadCount}
                              </Badge>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="status" className="h-full">
            <ScrollArea className="h-full">
              <div className="p-4">
                {/* My Status */}
                <div className="flex items-center p-3 hover:bg-gray-50 dark:hover:bg-gray-700 cursor-pointer rounded-lg transition-colors mb-4">
                  <div className="relative">
                    <Avatar className="w-12 h-12 border-2 border-dashed border-gray-400">
                      <AvatarImage src={state.currentUser?.avatar} />
                      <AvatarFallback>
                        <i className="fas fa-plus text-gray-400" />
                      </AvatarFallback>
                    </Avatar>
                  </div>
                  <div className="ml-3">
                    <h3 className="font-medium text-gray-900 dark:text-white">My Status</h3>
                    <p className="text-sm text-gray-600 dark:text-gray-300">Tap to add status update</p>
                  </div>
                </div>

                {/* Recent Status Updates */}
                {state.statusUpdates.length > 0 && (
                  <div>
                    <h4 className="text-sm font-medium text-gray-500 mb-3 uppercase tracking-wide">
                      Recent updates
                    </h4>
                    <div className="space-y-1">
                      {state.statusUpdates.map((status) => (
                        <div
                          key={status.id}
                          className="flex items-center p-3 hover:bg-gray-50 dark:hover:bg-gray-700 cursor-pointer rounded-lg transition-colors"
                          data-testid={`status-item-${status.id}`}
                        >
                          <div className="relative">
                            <div className="w-12 h-12 p-0.5 bg-gradient-to-r from-green-500 to-teal-600 rounded-full">
                              <Avatar className="w-full h-full border-2 border-white">
                                <AvatarImage src={status.user?.avatar} />
                                <AvatarFallback>
                                  {status.user?.name.charAt(0)}
                                </AvatarFallback>
                              </Avatar>
                            </div>
                          </div>
                          <div className="ml-3">
                            <h3 className="font-medium text-gray-900 dark:text-white">
                              {status.user?.name}
                            </h3>
                            <p className="text-sm text-gray-600 dark:text-gray-300">
                              {formatDistanceToNow(status.createdAt, { addSuffix: true })}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="contacts" className="h-full">
            <ScrollArea className="h-full">
              <div className="p-4">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Contacts</h3>
                  <Button 
                    className="bg-teal-600 hover:bg-teal-700"
                    onClick={onShowContact}
                    data-testid="button-add-contact"
                  >
                    <i className="fas fa-user-plus mr-2" />
                    Add
                  </Button>
                </div>

                <div className="space-y-2">
                  {filteredContacts.map((contact) => (
                    <div
                      key={contact.id}
                      className="flex items-center p-3 hover:bg-gray-50 dark:hover:bg-gray-700 cursor-pointer rounded-lg transition-colors"
                      data-testid={`contact-item-${contact.id}`}
                    >
                      <Avatar className="w-12 h-12">
                        <AvatarImage src={contact.user?.avatar} />
                        <AvatarFallback>
                          {contact.displayName?.charAt(0) || contact.user?.name.charAt(0)}
                        </AvatarFallback>
                      </Avatar>
                      
                      <div className="ml-3 flex-1">
                        <h3 className="font-medium text-gray-900 dark:text-white">
                          {contact.displayName || contact.user?.name}
                        </h3>
                        <p className="text-sm text-gray-600 dark:text-gray-300">
                          {contact.user?.status || 'Hey there! I am using WhatsApp Clone'}
                        </p>
                      </div>
                      
                      <div className="flex space-x-2">
                        <Button variant="ghost" size="sm" data-testid="button-call-contact">
                          <i className="fas fa-phone text-teal-600" />
                        </Button>
                        <Button variant="ghost" size="sm" data-testid="button-message-contact">
                          <i className="fas fa-comment text-teal-600" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="groups" className="h-full">
            <ScrollArea className="h-full">
              <div className="p-4">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Groups</h3>
                  <Button 
                    className="bg-teal-600 hover:bg-teal-700"
                    onClick={onShowGroup}
                    data-testid="button-create-group"
                  >
                    <i className="fas fa-users-plus mr-2" />
                    Create
                  </Button>
                </div>

                <div className="space-y-2">
                  {state.chats.filter(chat => chat.type === 'group').map((group) => (
                    <div
                      key={group.id}
                      className="flex items-center p-3 hover:bg-gray-50 dark:hover:bg-gray-700 cursor-pointer rounded-lg transition-colors"
                      onClick={() => handleChatClick(group)}
                      data-testid={`group-item-${group.id}`}
                    >
                      <Avatar className="w-12 h-12">
                        <AvatarImage src={group.avatar} />
                        <AvatarFallback className="bg-blue-500 text-white">
                          <i className="fas fa-users" />
                        </AvatarFallback>
                      </Avatar>
                      
                      <div className="ml-3 flex-1">
                        <div className="flex items-center space-x-2">
                          <h3 className="font-medium text-gray-900 dark:text-white">
                            {group.name}
                          </h3>
                          <Badge className="bg-teal-600 text-white">Admin</Badge>
                        </div>
                        <p className="text-sm text-gray-600 dark:text-gray-300">
                          {getLastMessagePreview(group)}
                        </p>
                        <p className="text-xs text-gray-500">
                          {group.participants?.length || 0} members
                        </p>
                      </div>
                      
                      <div className="flex flex-col items-end">
                        <span className="text-xs text-gray-500">
                          {formatDistanceToNow(group.updatedAt, { addSuffix: true })}
                        </span>
                        {getUnreadCount(group.id) > 0 && (
                          <Badge className="bg-green-500 text-white mt-1">
                            {getUnreadCount(group.id)}
                          </Badge>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </ScrollArea>
          </TabsContent>
        </div>
      </Tabs>

      {/* Floating Action Button */}
      <div className="absolute bottom-6 right-6">
        <Button
          className="w-14 h-14 bg-green-500 hover:bg-green-600 text-white rounded-full shadow-lg"
          onClick={onShowContact}
          data-testid="button-fab-new-chat"
        >
          <i className="fas fa-comment-plus text-xl" />
        </Button>
      </div>
    </div>
  );
}
