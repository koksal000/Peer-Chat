import React, { createContext, useContext, useReducer, useEffect } from 'react';
import { User, Chat, Message, Contact, StatusUpdate, TypingIndicator } from '@/types/chat';
import { useWebSocket } from '@/hooks/useWebSocket';
import { useIndexedDB } from '@/hooks/useIndexedDB';

interface ChatState {
  currentUser: User | null;
  activeChat: Chat | null;
  chats: Chat[];
  contacts: Contact[];
  messages: Record<string, Message[]>;
  statusUpdates: StatusUpdate[];
  typingIndicators: TypingIndicator[];
  onlineUsers: string[];
  isConnected: boolean;
  unknownMessages: Message[];
}

type ChatAction = 
  | { type: 'SET_USER'; payload: User }
  | { type: 'SET_ACTIVE_CHAT'; payload: Chat }
  | { type: 'ADD_CHAT'; payload: Chat }
  | { type: 'UPDATE_CHAT'; payload: Chat }
  | { type: 'SET_CHATS'; payload: Chat[] }
  | { type: 'ADD_MESSAGE'; payload: { chatId: string; message: Message } }
  | { type: 'SET_MESSAGES'; payload: { chatId: string; messages: Message[] } }
  | { type: 'UPDATE_MESSAGE_STATUS'; payload: { messageId: string; status: string } }
  | { type: 'SET_CONTACTS'; payload: Contact[] }
  | { type: 'ADD_CONTACT'; payload: Contact }
  | { type: 'REMOVE_CONTACT'; payload: string }
  | { type: 'SET_STATUS_UPDATES'; payload: StatusUpdate[] }
  | { type: 'ADD_STATUS_UPDATE'; payload: StatusUpdate }
  | { type: 'SET_TYPING'; payload: TypingIndicator }
  | { type: 'CLEAR_TYPING'; payload: { userId: string; chatId: string } }
  | { type: 'SET_ONLINE_USERS'; payload: string[] }
  | { type: 'SET_CONNECTION_STATUS'; payload: boolean }
  | { type: 'ADD_UNKNOWN_MESSAGE'; payload: Message };

const initialState: ChatState = {
  currentUser: null,
  activeChat: null,
  chats: [],
  contacts: [],
  messages: {},
  statusUpdates: [],
  typingIndicators: [],
  onlineUsers: [],
  isConnected: false,
  unknownMessages: [],
};

function chatReducer(state: ChatState, action: ChatAction): ChatState {
  switch (action.type) {
    case 'SET_USER':
      return { ...state, currentUser: action.payload };
    
    case 'SET_ACTIVE_CHAT':
      return { ...state, activeChat: action.payload };
    
    case 'ADD_CHAT':
      return { ...state, chats: [...state.chats, action.payload] };
    
    case 'UPDATE_CHAT':
      return {
        ...state,
        chats: state.chats.map(chat => 
          chat.id === action.payload.id ? action.payload : chat
        )
      };
    
    case 'SET_CHATS':
      return { ...state, chats: action.payload };
    
    case 'ADD_MESSAGE':
      const { chatId, message } = action.payload;
      return {
        ...state,
        messages: {
          ...state.messages,
          [chatId]: [...(state.messages[chatId] || []), message]
        }
      };
    
    case 'SET_MESSAGES':
      return {
        ...state,
        messages: {
          ...state.messages,
          [action.payload.chatId]: action.payload.messages
        }
      };
    
    case 'UPDATE_MESSAGE_STATUS':
      const updatedMessages = { ...state.messages };
      Object.keys(updatedMessages).forEach(chatId => {
        updatedMessages[chatId] = updatedMessages[chatId].map(msg =>
          msg.id === action.payload.messageId
            ? { ...msg, status: action.payload.status as any }
            : msg
        );
      });
      return { ...state, messages: updatedMessages };
    
    case 'SET_CONTACTS':
      return { ...state, contacts: action.payload };
    
    case 'ADD_CONTACT':
      return { ...state, contacts: [...state.contacts, action.payload] };
    
    case 'REMOVE_CONTACT':
      return {
        ...state,
        contacts: state.contacts.filter(contact => contact.id !== action.payload)
      };
    
    case 'SET_STATUS_UPDATES':
      return { ...state, statusUpdates: action.payload };
    
    case 'ADD_STATUS_UPDATE':
      return { ...state, statusUpdates: [action.payload, ...state.statusUpdates] };
    
    case 'SET_TYPING':
      const existingTypingIndex = state.typingIndicators.findIndex(
        t => t.userId === action.payload.userId && t.chatId === action.payload.chatId
      );
      
      if (existingTypingIndex >= 0) {
        const updated = [...state.typingIndicators];
        updated[existingTypingIndex] = action.payload;
        return { ...state, typingIndicators: updated };
      }
      
      return {
        ...state,
        typingIndicators: [...state.typingIndicators, action.payload]
      };
    
    case 'CLEAR_TYPING':
      return {
        ...state,
        typingIndicators: state.typingIndicators.filter(
          t => !(t.userId === action.payload.userId && t.chatId === action.payload.chatId)
        )
      };
    
    case 'SET_ONLINE_USERS':
      return { ...state, onlineUsers: action.payload };
    
    case 'SET_CONNECTION_STATUS':
      return { ...state, isConnected: action.payload };
    
    case 'ADD_UNKNOWN_MESSAGE':
      return { ...state, unknownMessages: [...state.unknownMessages, action.payload] };
    
    default:
      return state;
  }
}

interface ChatContextType {
  state: ChatState;
  dispatch: React.Dispatch<ChatAction>;
  sendMessage: (chatId: string, content: string, type?: string) => Promise<void>;
  createChat: (type: string, name?: string, participants?: string[]) => Promise<Chat | null>;
  addContact: (peerId: string, displayName?: string) => Promise<void>;
  removeContact: (contactId: string) => Promise<void>;
  blockContact: (contactId: string, blocked: boolean) => Promise<void>;
  postStatus: (content: string, type: string, caption?: string) => Promise<void>;
  setActiveChat: (chat: Chat | null) => void;
  startTyping: (chatId: string) => void;
  stopTyping: (chatId: string) => void;
}

const ChatContext = createContext<ChatContextType | undefined>(undefined);

export function ChatProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(chatReducer, initialState);
  const { sendMessage: wsSendMessage, isConnected } = useWebSocket({
    onMessage: (message) => {
      handleWebSocketMessage(message);
    },
    onConnect: () => {
      dispatch({ type: 'SET_CONNECTION_STATUS', payload: true });
      if (state.currentUser) {
        wsSendMessage({
          type: 'register',
          data: {
            userId: state.currentUser.id,
            peerId: state.currentUser.peerId
          }
        });
      }
    },
    onDisconnect: () => {
      dispatch({ type: 'SET_CONNECTION_STATUS', payload: false });
    }
  });
  
  const db = useIndexedDB();

  useEffect(() => {
    dispatch({ type: 'SET_CONNECTION_STATUS', payload: isConnected });
  }, [isConnected]);

  const handleWebSocketMessage = (message: any) => {
    switch (message.type) {
      case 'message':
        const newMessage = message.data as Message;
        dispatch({ 
          type: 'ADD_MESSAGE', 
          payload: { chatId: newMessage.chatId, message: newMessage } 
        });
        break;
      
      case 'typing':
        if (message.data.isTyping) {
          dispatch({ type: 'SET_TYPING', payload: message.data });
        } else {
          dispatch({ 
            type: 'CLEAR_TYPING', 
            payload: { userId: message.data.userId, chatId: message.data.chatId } 
          });
        }
        break;
      
      case 'status':
        const statusData = message.data;
        if (statusData.isOnline !== undefined) {
          // User online status update
          dispatch({ type: 'SET_ONLINE_USERS', payload: [statusData.userId] });
        } else {
          // Status update
          dispatch({ type: 'ADD_STATUS_UPDATE', payload: statusData });
        }
        break;
    }
  };

  const sendMessage = async (chatId: string, content: string, type = 'text') => {
    if (!state.currentUser) return;

    try {
      const response = await fetch('/api/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chatId,
          senderId: state.currentUser.id,
          type,
          content
        })
      });

      if (response.ok) {
        const message = await response.json();
        dispatch({ 
          type: 'ADD_MESSAGE', 
          payload: { chatId, message } 
        });
      }
    } catch (error) {
      console.error('Failed to send message:', error);
    }
  };

  const createChat = async (type: string, name?: string, participants?: string[]) => {
    if (!state.currentUser) return null;

    try {
      const response = await fetch('/api/chats', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type,
          name,
          createdBy: state.currentUser.id
        })
      });

      if (response.ok) {
        const chat = await response.json();
        
        // Add participants if provided
        if (participants) {
          for (const participantId of participants) {
            await fetch(`/api/chats/${chat.id}/participants`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ userId: participantId })
            });
          }
        }

        dispatch({ type: 'ADD_CHAT', payload: chat });
        return chat;
      }
    } catch (error) {
      console.error('Failed to create chat:', error);
    }
    return null;
  };

  const addContact = async (peerId: string, displayName?: string) => {
    if (!state.currentUser) return;

    try {
      // First find the user by peerId
      const userResponse = await fetch(`/api/users/peer/${peerId}`);
      if (!userResponse.ok) {
        throw new Error('User not found');
      }
      
      const contactUser = await userResponse.json();
      
      const response = await fetch('/api/contacts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: state.currentUser.id,
          contactId: contactUser.id,
          displayName
        })
      });

      if (response.ok) {
        const contact = await response.json();
        dispatch({ type: 'ADD_CONTACT', payload: contact });
      }
    } catch (error) {
      console.error('Failed to add contact:', error);
      throw error;
    }
  };

  const removeContact = async (contactId: string) => {
    if (!state.currentUser) return;

    try {
      const response = await fetch(`/api/contacts/${state.currentUser.id}/${contactId}`, {
        method: 'DELETE'
      });

      if (response.ok) {
        dispatch({ type: 'REMOVE_CONTACT', payload: contactId });
      }
    } catch (error) {
      console.error('Failed to remove contact:', error);
    }
  };

  const blockContact = async (contactId: string, blocked: boolean) => {
    if (!state.currentUser) return;

    try {
      const response = await fetch(`/api/contacts/${state.currentUser.id}/${contactId}/block`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ blocked })
      });

      if (response.ok) {
        // Update local state
        const updatedContacts = state.contacts.map(contact => 
          contact.contactId === contactId 
            ? { ...contact, isBlocked: blocked }
            : contact
        );
        dispatch({ type: 'SET_CONTACTS', payload: updatedContacts });
      }
    } catch (error) {
      console.error('Failed to block/unblock contact:', error);
    }
  };

  const postStatus = async (content: string, type: string, caption?: string) => {
    if (!state.currentUser) return;

    try {
      const response = await fetch('/api/status', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: state.currentUser.id,
          type,
          content,
          caption
        })
      });

      if (response.ok) {
        const status = await response.json();
        dispatch({ type: 'ADD_STATUS_UPDATE', payload: status });
      }
    } catch (error) {
      console.error('Failed to post status:', error);
    }
  };

  const setActiveChat = (chat: Chat | null) => {
    dispatch({ type: 'SET_ACTIVE_CHAT', payload: chat });
  };

  const startTyping = (chatId: string) => {
    if (!state.currentUser) return;
    
    wsSendMessage({
      type: 'typing',
      data: {
        userId: state.currentUser.id,
        chatId,
        isTyping: true
      },
      chatId
    });
  };

  const stopTyping = (chatId: string) => {
    if (!state.currentUser) return;
    
    wsSendMessage({
      type: 'typing',
      data: {
        userId: state.currentUser.id,
        chatId,
        isTyping: false
      },
      chatId
    });
  };

  const contextValue: ChatContextType = {
    state,
    dispatch,
    sendMessage,
    createChat,
    addContact,
    removeContact,
    blockContact,
    postStatus,
    setActiveChat,
    startTyping,
    stopTyping
  };

  return (
    <ChatContext.Provider value={contextValue}>
      {children}
    </ChatContext.Provider>
  );
}

export function useChatContext() {
  const context = useContext(ChatContext);
  if (!context) {
    throw new Error('useChatContext must be used within a ChatProvider');
  }
  return context;
}
