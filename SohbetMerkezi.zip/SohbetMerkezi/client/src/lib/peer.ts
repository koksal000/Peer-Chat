import Peer, { DataConnection } from 'peerjs';
import { Message, PeerConnection } from '@/types/chat';

export class PeerManager {
  private peer: Peer | null = null;
  private connections = new Map<string, DataConnection>();
  private messageHandlers = new Set<(message: any) => void>();
  private connectionHandlers = new Set<(peerId: string, connected: boolean) => void>();
  private isInitialized = false;

  async initialize(peerId?: string): Promise<string> {
    return new Promise((resolve, reject) => {
      // Clean up existing peer if any
      if (this.peer) {
        this.peer.destroy();
      }

      // Create new peer instance
      this.peer = new Peer(peerId, {
        host: 'localhost',
        port: 9000,
        path: '/myapp',
        debug: 2,
        config: {
          iceServers: [
            { urls: 'stun:stun.l.google.com:19302' },
            { urls: 'stun:stun1.l.google.com:19302' }
          ]
        }
      });

      this.peer.on('open', (id) => {
        console.log('Peer connection opened with ID:', id);
        this.isInitialized = true;
        resolve(id);
      });

      this.peer.on('connection', (conn) => {
        this.handleIncomingConnection(conn);
      });

      this.peer.on('error', (error) => {
        console.error('Peer error:', error);
        this.isInitialized = false;
        reject(error);
      });

      this.peer.on('disconnected', () => {
        console.log('Peer disconnected, attempting to reconnect...');
        this.isInitialized = false;
        if (!this.peer?.destroyed) {
          this.peer?.reconnect();
        }
      });

      this.peer.on('close', () => {
        console.log('Peer connection closed');
        this.isInitialized = false;
      });

      // Set timeout for connection
      setTimeout(() => {
        if (!this.isInitialized) {
          reject(new Error('Peer connection timeout'));
        }
      }, 10000);
    });
  }

  private handleIncomingConnection(conn: DataConnection) {
    console.log('Incoming connection from:', conn.peer);
    
    conn.on('open', () => {
      console.log('Incoming connection opened:', conn.peer);
      this.connections.set(conn.peer, conn);
      this.notifyConnectionHandlers(conn.peer, true);
    });

    conn.on('data', (data) => {
      this.handleReceivedData(conn.peer, data);
    });

    conn.on('close', () => {
      console.log('Incoming connection closed:', conn.peer);
      this.connections.delete(conn.peer);
      this.notifyConnectionHandlers(conn.peer, false);
    });

    conn.on('error', (error) => {
      console.error('Incoming connection error:', error);
      this.connections.delete(conn.peer);
      this.notifyConnectionHandlers(conn.peer, false);
    });
  }

  async connectToPeer(peerId: string): Promise<boolean> {
    if (!this.peer || !this.isInitialized) {
      throw new Error('Peer not initialized');
    }

    if (this.connections.has(peerId)) {
      console.log('Already connected to peer:', peerId);
      return true;
    }

    return new Promise((resolve, reject) => {
      const conn = this.peer!.connect(peerId, {
        reliable: true,
        metadata: { timestamp: Date.now() }
      });

      conn.on('open', () => {
        console.log('Outgoing connection opened to:', peerId);
        this.connections.set(peerId, conn);
        this.notifyConnectionHandlers(peerId, true);
        resolve(true);
      });

      conn.on('data', (data) => {
        this.handleReceivedData(peerId, data);
      });

      conn.on('close', () => {
        console.log('Outgoing connection closed to:', peerId);
        this.connections.delete(peerId);
        this.notifyConnectionHandlers(peerId, false);
      });

      conn.on('error', (error) => {
        console.error('Outgoing connection error:', error);
        this.connections.delete(peerId);
        this.notifyConnectionHandlers(peerId, false);
        reject(error);
      });

      // Set timeout for connection
      setTimeout(() => {
        if (!this.connections.has(peerId)) {
          reject(new Error('Connection timeout'));
        }
      }, 10000);
    });
  }

  private handleReceivedData(fromPeerId: string, data: any) {
    console.log('Received data from:', fromPeerId, data);
    
    try {
      const message = typeof data === 'string' ? JSON.parse(data) : data;
      message.fromPeerId = fromPeerId;
      message.timestamp = message.timestamp || Date.now();
      
      this.notifyMessageHandlers(message);
    } catch (error) {
      console.error('Error parsing received data:', error);
    }
  }

  sendMessage(peerId: string, message: any): boolean {
    const connection = this.connections.get(peerId);
    
    if (!connection || connection.open !== true) {
      console.error('No active connection to peer:', peerId);
      return false;
    }

    try {
      const messageData = {
        ...message,
        timestamp: Date.now(),
        fromPeerId: this.peer?.id
      };
      
      connection.send(messageData);
      console.log('Message sent to:', peerId, messageData);
      return true;
    } catch (error) {
      console.error('Error sending message:', error);
      return false;
    }
  }

  broadcastMessage(message: any, excludePeers: string[] = []): void {
    const messageData = {
      ...message,
      timestamp: Date.now(),
      fromPeerId: this.peer?.id
    };

    this.connections.forEach((connection, peerId) => {
      if (!excludePeers.includes(peerId) && connection.open) {
        try {
          connection.send(messageData);
          console.log('Broadcast message sent to:', peerId);
        } catch (error) {
          console.error('Error broadcasting to:', peerId, error);
        }
      }
    });
  }

  disconnectFromPeer(peerId: string): void {
    const connection = this.connections.get(peerId);
    if (connection) {
      connection.close();
      this.connections.delete(peerId);
      this.notifyConnectionHandlers(peerId, false);
    }
  }

  disconnectAll(): void {
    this.connections.forEach((connection, peerId) => {
      connection.close();
    });
    this.connections.clear();
  }

  destroy(): void {
    this.disconnectAll();
    if (this.peer) {
      this.peer.destroy();
      this.peer = null;
    }
    this.isInitialized = false;
    this.messageHandlers.clear();
    this.connectionHandlers.clear();
  }

  // Event handlers
  onMessage(handler: (message: any) => void): () => void {
    this.messageHandlers.add(handler);
    return () => this.messageHandlers.delete(handler);
  }

  onConnection(handler: (peerId: string, connected: boolean) => void): () => void {
    this.connectionHandlers.add(handler);
    return () => this.connectionHandlers.delete(handler);
  }

  private notifyMessageHandlers(message: any): void {
    this.messageHandlers.forEach(handler => {
      try {
        handler(message);
      } catch (error) {
        console.error('Error in message handler:', error);
      }
    });
  }

  private notifyConnectionHandlers(peerId: string, connected: boolean): void {
    this.connectionHandlers.forEach(handler => {
      try {
        handler(peerId, connected);
      } catch (error) {
        console.error('Error in connection handler:', error);
      }
    });
  }

  // Getters
  get peerId(): string | null {
    return this.peer?.id || null;
  }

  get isConnected(): boolean {
    return this.isInitialized && !this.peer?.destroyed;
  }

  getConnectedPeers(): string[] {
    return Array.from(this.connections.keys()).filter(peerId => {
      const conn = this.connections.get(peerId);
      return conn?.open === true;
    });
  }

  isPeerConnected(peerId: string): boolean {
    const connection = this.connections.get(peerId);
    return connection?.open === true;
  }

  getConnectionInfo(peerId: string): PeerConnection | null {
    const connection = this.connections.get(peerId);
    if (!connection) return null;

    return {
      peerId,
      connection,
      isConnected: connection.open === true
    };
  }
}

export const peerManager = new PeerManager();
