const GEMINI_API_ENDPOINT = '/api/ai';

export interface GeminiResponse {
  content: string;
  type: 'text' | 'code' | 'error';
  metadata?: Record<string, any>;
}

class GeminiClient {
  private conversationHistory: Array<{ role: 'user' | 'assistant'; content: string }> = [];

  async sendMessage(message: string): Promise<GeminiResponse> {
    try {
      // Add user message to history
      this.conversationHistory.push({ role: 'user', content: message });
      
      // Keep only last 10 messages to avoid token limits
      if (this.conversationHistory.length > 10) {
        this.conversationHistory = this.conversationHistory.slice(-10);
      }

      const response = await fetch(`${GEMINI_API_ENDPOINT}/chat`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          message,
          context: this.conversationHistory.slice(0, -1).map(h => `${h.role}: ${h.content}`)
        })
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      
      // Add assistant response to history
      this.conversationHistory.push({ role: 'assistant', content: data.content });
      
      return data;
    } catch (error) {
      console.error('Gemini API error:', error);
      return {
        content: 'I apologize, but I encountered an error. Please try again.',
        type: 'error',
        metadata: { error: error instanceof Error ? error.message : 'Unknown error' }
      };
    }
  }

  async analyzeImage(file: File, prompt?: string): Promise<GeminiResponse> {
    try {
      const formData = new FormData();
      formData.append('image', file);
      if (prompt) {
        formData.append('prompt', prompt);
      }

      const response = await fetch(`${GEMINI_API_ENDPOINT}/analyze-image`, {
        method: 'POST',
        body: formData
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Image analysis error:', error);
      return {
        content: 'I encountered an error while analyzing the image.',
        type: 'error'
      };
    }
  }

  async getCodeHelp(request: string, language?: string): Promise<GeminiResponse> {
    try {
      const response = await fetch(`${GEMINI_API_ENDPOINT}/code-help`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ request, language })
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Code help error:', error);
      return {
        content: 'I encountered an error while generating code help.',
        type: 'error'
      };
    }
  }

  clearHistory(): void {
    this.conversationHistory = [];
  }

  getHistory(): Array<{ role: 'user' | 'assistant'; content: string }> {
    return [...this.conversationHistory];
  }

  // Pre-defined prompts for common tasks
  async getQuickResponse(type: 'greeting' | 'help' | 'features'): Promise<GeminiResponse> {
    const prompts = {
      greeting: "Hello! I'm Gemini AI Assistant. How can I help you today?",
      help: "I can help you with:\n• Code generation and debugging\n• Writing and editing text\n• Image analysis\n• Data analysis and calculations\n• Creative projects\n• General questions and conversations\n\nWhat would you like me to assist you with?",
      features: "Here are some things I can do:\n\n🔧 **Code & Development**\n• Generate code in any programming language\n• Debug and optimize existing code\n• Explain complex programming concepts\n\n📝 **Writing & Content**\n• Write articles, emails, and documents\n• Proofread and improve existing text\n• Creative writing and storytelling\n\n📊 **Analysis & Problem Solving**\n• Analyze data and create reports\n• Solve mathematical problems\n• Provide research insights\n\n🎨 **Creative Tasks**\n• Brainstorm ideas\n• Create project plans\n• Design workflows\n\nWhat would you like to explore?"
    };

    return {
      content: prompts[type],
      type: 'text',
      metadata: { type: 'quick_response' }
    };
  }

  // Format code in responses
  formatCodeResponse(content: string): string {
    // Add syntax highlighting hints for markdown rendering
    return content.replace(/```(\w+)?\n([\s\S]*?)```/g, (match, lang, code) => {
      return `\`\`\`${lang || 'javascript'}\n${code}\`\`\``;
    });
  }

  // Extract code blocks from response
  extractCodeBlocks(content: string): Array<{ language: string; code: string }> {
    const codeBlocks: Array<{ language: string; code: string }> = [];
    const regex = /```(\w+)?\n([\s\S]*?)```/g;
    let match;

    while ((match = regex.exec(content)) !== null) {
      codeBlocks.push({
        language: match[1] || 'text',
        code: match[2].trim()
      });
    }

    return codeBlocks;
  }

  // Check if response contains code
  hasCode(content: string): boolean {
    return /```[\s\S]*?```/.test(content) || 
           content.includes('function ') || 
           content.includes('class ') ||
           content.includes('const ') ||
           content.includes('let ') ||
           content.includes('var ');
  }
}

export const geminiClient = new GeminiClient();
