import { Chat, Message, Contact, StatusUpdate, FileRecord, UnknownMessage } from '@/types/chat';

class IndexedDBManager {
  private db: IDBDatabase | null = null;
  private dbName = 'WhatsAppClone';
  private version = 1;

  async init(): Promise<void> {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(this.dbName, this.version);

      request.onerror = () => reject(request.error);
      request.onsuccess = () => {
        this.db = request.result;
        resolve();
      };

      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;

        // Messages store
        if (!db.objectStoreNames.contains('messages')) {
          const messageStore = db.createObjectStore('messages', { keyPath: 'id' });
          messageStore.createIndex('chatId', 'chatId', { unique: false });
          messageStore.createIndex('timestamp', 'timestamp', { unique: false });
          messageStore.createIndex('senderId', 'senderId', { unique: false });
        }

        // Chats store
        if (!db.objectStoreNames.contains('chats')) {
          const chatStore = db.createObjectStore('chats', { keyPath: 'id' });
          chatStore.createIndex('type', 'type', { unique: false });
          chatStore.createIndex('updatedAt', 'updatedAt', { unique: false });
        }

        // Contacts store
        if (!db.objectStoreNames.contains('contacts')) {
          const contactStore = db.createObjectStore('contacts', { keyPath: 'id' });
          contactStore.createIndex('userId', 'userId', { unique: false });
          contactStore.createIndex('contactId', 'contactId', { unique: false });
        }

        // Status updates store
        if (!db.objectStoreNames.contains('statusUpdates')) {
          const statusStore = db.createObjectStore('statusUpdates', { keyPath: 'id' });
          statusStore.createIndex('userId', 'userId', { unique: false });
          statusStore.createIndex('createdAt', 'createdAt', { unique: false });
        }

        // Files store
        if (!db.objectStoreNames.contains('files')) {
          const fileStore = db.createObjectStore('files', { keyPath: 'id' });
          fileStore.createIndex('uploadedBy', 'uploadedBy', { unique: false });
          fileStore.createIndex('uploadedAt', 'uploadedAt', { unique: false });
        }

        // Unknown messages store
        if (!db.objectStoreNames.contains('unknownMessages')) {
          const unknownStore = db.createObjectStore('unknownMessages', { keyPath: 'id' });
          unknownStore.createIndex('recipientId', 'recipientId', { unique: false });
          unknownStore.createIndex('timestamp', 'timestamp', { unique: false });
        }

        // User settings store
        if (!db.objectStoreNames.contains('settings')) {
          db.createObjectStore('settings', { keyPath: 'key' });
        }

        // Chat drafts store
        if (!db.objectStoreNames.contains('drafts')) {
          db.createObjectStore('drafts', { keyPath: 'chatId' });
        }
      };
    });
  }

  private getStore(storeName: string, mode: IDBTransactionMode = 'readonly'): IDBObjectStore {
    if (!this.db) {
      throw new Error('Database not initialized');
    }
    const transaction = this.db.transaction([storeName], mode);
    return transaction.objectStore(storeName);
  }

  // Message operations
  async saveMessage(message: Message): Promise<void> {
    const store = this.getStore('messages', 'readwrite');
    await this.promisifyRequest(store.put(message));
  }

  async getMessages(chatId: string, limit = 50, offset = 0): Promise<Message[]> {
    const store = this.getStore('messages');
    const index = store.index('chatId');
    const range = IDBKeyRange.only(chatId);
    
    return new Promise((resolve, reject) => {
      const messages: Message[] = [];
      let skipped = 0;
      let added = 0;
      
      const request = index.openCursor(range, 'prev'); // Get newest first
      
      request.onsuccess = () => {
        const cursor = request.result;
        if (cursor && added < limit) {
          if (skipped >= offset) {
            messages.push(cursor.value);
            added++;
          } else {
            skipped++;
          }
          cursor.continue();
        } else {
          resolve(messages.reverse()); // Return in chronological order
        }
      };
      
      request.onerror = () => reject(request.error);
    });
  }

  async deleteMessage(messageId: string): Promise<void> {
    const store = this.getStore('messages', 'readwrite');
    await this.promisifyRequest(store.delete(messageId));
  }

  async searchMessages(query: string, chatId?: string): Promise<Message[]> {
    const store = this.getStore('messages');
    
    return new Promise((resolve, reject) => {
      const messages: Message[] = [];
      const request = store.openCursor();
      
      request.onsuccess = () => {
        const cursor = request.result;
        if (cursor) {
          const message = cursor.value as Message;
          const matchesChat = !chatId || message.chatId === chatId;
          const matchesQuery = message.content.toLowerCase().includes(query.toLowerCase());
          
          if (matchesChat && matchesQuery && !message.isDeleted) {
            messages.push(message);
          }
          
          cursor.continue();
        } else {
          resolve(messages.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime()));
        }
      };
      
      request.onerror = () => reject(request.error);
    });
  }

  // Chat operations
  async saveChat(chat: Chat): Promise<void> {
    const store = this.getStore('chats', 'readwrite');
    await this.promisifyRequest(store.put(chat));
  }

  async getChats(): Promise<Chat[]> {
    const store = this.getStore('chats');
    const request = store.getAll();
    const chats = await this.promisifyRequest(request) as Chat[];
    return chats.sort((a, b) => b.updatedAt.getTime() - a.updatedAt.getTime());
  }

  async getChat(chatId: string): Promise<Chat | undefined> {
    const store = this.getStore('chats');
    const request = store.get(chatId);
    return await this.promisifyRequest(request) as Chat | undefined;
  }

  async deleteChat(chatId: string): Promise<void> {
    const transaction = this.db!.transaction(['chats', 'messages'], 'readwrite');
    
    // Delete chat
    const chatStore = transaction.objectStore('chats');
    await this.promisifyRequest(chatStore.delete(chatId));
    
    // Delete messages
    const messageStore = transaction.objectStore('messages');
    const index = messageStore.index('chatId');
    const range = IDBKeyRange.only(chatId);
    
    return new Promise((resolve, reject) => {
      const request = index.openCursor(range);
      request.onsuccess = () => {
        const cursor = request.result;
        if (cursor) {
          cursor.delete();
          cursor.continue();
        } else {
          resolve();
        }
      };
      request.onerror = () => reject(request.error);
    });
  }

  // Contact operations
  async saveContact(contact: Contact): Promise<void> {
    const store = this.getStore('contacts', 'readwrite');
    await this.promisifyRequest(store.put(contact));
  }

  async getContacts(userId: string): Promise<Contact[]> {
    const store = this.getStore('contacts');
    const index = store.index('userId');
    const range = IDBKeyRange.only(userId);
    const request = index.getAll(range);
    return await this.promisifyRequest(request) as Contact[];
  }

  async deleteContact(contactId: string): Promise<void> {
    const store = this.getStore('contacts', 'readwrite');
    await this.promisifyRequest(store.delete(contactId));
  }

  // Status operations
  async saveStatus(status: StatusUpdate): Promise<void> {
    const store = this.getStore('statusUpdates', 'readwrite');
    await this.promisifyRequest(store.put(status));
  }

  async getStatuses(userId?: string): Promise<StatusUpdate[]> {
    const store = this.getStore('statusUpdates');
    
    if (userId) {
      const index = store.index('userId');
      const range = IDBKeyRange.only(userId);
      const request = index.getAll(range);
      return await this.promisifyRequest(request) as StatusUpdate[];
    } else {
      const request = store.getAll();
      const statuses = await this.promisifyRequest(request) as StatusUpdate[];
      return statuses.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
    }
  }

  async deleteExpiredStatuses(): Promise<void> {
    const store = this.getStore('statusUpdates', 'readwrite');
    const now = new Date();
    
    return new Promise((resolve, reject) => {
      const request = store.openCursor();
      request.onsuccess = () => {
        const cursor = request.result;
        if (cursor) {
          const status = cursor.value as StatusUpdate;
          if (status.expiresAt && status.expiresAt < now) {
            cursor.delete();
          }
          cursor.continue();
        } else {
          resolve();
        }
      };
      request.onerror = () => reject(request.error);
    });
  }

  // File operations
  async saveFile(file: FileRecord): Promise<void> {
    const store = this.getStore('files', 'readwrite');
    await this.promisifyRequest(store.put(file));
  }

  async getFile(fileId: string): Promise<FileRecord | undefined> {
    const store = this.getStore('files');
    const request = store.get(fileId);
    return await this.promisifyRequest(request) as FileRecord | undefined;
  }

  // Unknown messages operations
  async saveUnknownMessage(message: UnknownMessage): Promise<void> {
    const store = this.getStore('unknownMessages', 'readwrite');
    await this.promisifyRequest(store.put(message));
  }

  async getUnknownMessages(recipientId: string): Promise<UnknownMessage[]> {
    const store = this.getStore('unknownMessages');
    const index = store.index('recipientId');
    const range = IDBKeyRange.only(recipientId);
    const request = index.getAll(range);
    const messages = await this.promisifyRequest(request) as UnknownMessage[];
    return messages.filter(m => !m.isAccepted).sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
  }

  async markUnknownMessageAccepted(messageId: string): Promise<void> {
    const store = this.getStore('unknownMessages', 'readwrite');
    const request = store.get(messageId);
    const message = await this.promisifyRequest(request) as UnknownMessage;
    
    if (message) {
      message.isAccepted = true;
      await this.promisifyRequest(store.put(message));
    }
  }

  // Settings operations
  async saveSetting(key: string, value: any): Promise<void> {
    const store = this.getStore('settings', 'readwrite');
    await this.promisifyRequest(store.put({ key, value }));
  }

  async getSetting(key: string): Promise<any> {
    const store = this.getStore('settings');
    const request = store.get(key);
    const result = await this.promisifyRequest(request);
    return result?.value;
  }

  // Draft operations
  async saveDraft(chatId: string, content: string): Promise<void> {
    const store = this.getStore('drafts', 'readwrite');
    await this.promisifyRequest(store.put({ chatId, content, timestamp: new Date() }));
  }

  async getDraft(chatId: string): Promise<string | undefined> {
    const store = this.getStore('drafts');
    const request = store.get(chatId);
    const result = await this.promisifyRequest(request);
    return result?.content;
  }

  async deleteDraft(chatId: string): Promise<void> {
    const store = this.getStore('drafts', 'readwrite');
    await this.promisifyRequest(store.delete(chatId));
  }

  // Utility method to promisify IDB requests
  private promisifyRequest<T>(request: IDBRequest): Promise<T> {
    return new Promise((resolve, reject) => {
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  // Clear all data
  async clearAllData(): Promise<void> {
    if (!this.db) return;
    
    const storeNames = Array.from(this.db.objectStoreNames);
    const transaction = this.db.transaction(storeNames, 'readwrite');
    
    const promises = storeNames.map(storeName => {
      const store = transaction.objectStore(storeName);
      return this.promisifyRequest(store.clear());
    });
    
    await Promise.all(promises);
  }
}

export const indexedDB = new IndexedDBManager();
