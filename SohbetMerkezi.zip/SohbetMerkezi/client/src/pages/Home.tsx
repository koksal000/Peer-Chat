import React, { useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { useWebSocket } from '../hooks/useWebSocket';
import { usePeer } from '../hooks/usePeer';
import { useIndexedDB } from '../hooks/useIndexedDB';
import ChatSidebar from '../components/ChatSidebar';
import ChatArea from '../components/ChatArea';
import ContactInfo from '../components/ContactInfo';
import StatusModal from '../components/StatusModal';
import GroupModal from '../components/GroupModal';
import ContactModal from '../components/ContactModal';
import { WSMessage } from '../types';

export default function Home() {
  const { state, dispatch } = useApp();
  const { saveMessage, getChats, getContacts } = useIndexedDB();
  
  const { sendMessage: sendWSMessage, registerPeer } = useWebSocket({
    onMessage: (message: WSMessage) => {
      console.log('Received WebSocket message:', message);
      // Handle real-time updates
    },
    onConnect: () => {
      dispatch({ type: 'SET_CONNECTION_STATUS', payload: 'connected' });
    },
    onDisconnect: () => {
      dispatch({ type: 'SET_CONNECTION_STATUS', payload: 'disconnected' });
    },
  });

  const { peerId, isReady } = usePeer();

  // Initialize user and load data
  useEffect(() => {
    const initializeApp = async () => {
      dispatch({ type: 'SET_LOADING', payload: true });
      
      try {
        // Create or load user
        if (!state.currentUser && peerId) {
          const user = {
            id: crypto.randomUUID(),
            peerId: peerId,
            name: localStorage.getItem('userName') || 'User',
            status: 'Available',
            isOnline: true,
            lastSeen: new Date(),
          };
          
          dispatch({ type: 'SET_USER', payload: user });
          
          // Register with WebSocket
          if (isReady) {
            registerPeer(peerId);
          }
        }

        // Load saved data
        const [chats, contacts] = await Promise.all([
          getChats(),
          getContacts(),
        ]);

        dispatch({ type: 'SET_CHATS', payload: chats });
        dispatch({ type: 'SET_CONTACTS', payload: contacts });
        
      } catch (error) {
        console.error('Failed to initialize app:', error);
        dispatch({ type: 'SET_ERROR', payload: 'Failed to initialize application' });
      } finally {
        dispatch({ type: 'SET_LOADING', payload: false });
      }
    };

    initializeApp();
  }, [peerId, isReady, dispatch, getChats, getContacts, registerPeer, state.currentUser]);

  if (state.isLoading) {
    return (
      <div className="h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-500 mx-auto mb-4"></div>
          <p className="text-gray-600 dark:text-gray-400">Initializing WhatsApp Clone...</p>
        </div>
      </div>
    );
  }

  if (state.error) {
    return (
      <div className="h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900">
        <div className="text-center">
          <div className="text-red-500 text-6xl mb-4">⚠️</div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">Application Error</h1>
          <p className="text-gray-600 dark:text-gray-400 mb-4">{state.error}</p>
          <button 
            onClick={() => window.location.reload()} 
            className="bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600 transition-colors"
          >
            Reload Application
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen flex overflow-hidden bg-gray-100 dark:bg-gray-900">
      {/* Left Sidebar */}
      <ChatSidebar />
      
      {/* Main Chat Area */}
      <ChatArea />
      
      {/* Right Panel - Contact Info */}
      <ContactInfo />
      
      {/* Modals */}
      <StatusModal />
      <GroupModal />
      <ContactModal />
      
      {/* Connection Status */}
      <div className="fixed bottom-4 left-4 flex items-center space-x-2 bg-white dark:bg-gray-800 rounded-lg shadow-lg px-3 py-2 text-sm">
        <div className={`w-2 h-2 rounded-full ${
          state.connectionStatus === 'connected' ? 'bg-green-500' : 
          state.connectionStatus === 'connecting' ? 'bg-yellow-500' : 'bg-red-500'
        }`} />
        <span className="text-gray-700 dark:text-gray-300 capitalize">
          {state.connectionStatus}
        </span>
        {peerId && (
          <span className="text-gray-500 text-xs">
            ID: {peerId.slice(-8)}
          </span>
        )}
      </div>
    </div>
  );
}
