import { useEffect, useState } from 'react';
import { useChatContext } from '@/contexts/ChatContext';
import ChatSidebar from '@/components/ChatSidebar';
import ChatArea from '@/components/ChatArea';
import ContactInfo from '@/components/ContactInfo';
import StatusModal from '@/components/StatusModal';
import GroupModal from '@/components/GroupModal';
import ContactModal from '@/components/ContactModal';
import { User } from '@/types/chat';
import { useToast } from '@/hooks/use-toast';

export default function ChatPage() {
  const { state, dispatch } = useChatContext();
  const [showContactInfo, setShowContactInfo] = useState(false);
  const [showStatusModal, setShowStatusModal] = useState(false);
  const [showGroupModal, setShowGroupModal] = useState(false);
  const [showContactModal, setShowContactModal] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    initializeUser();
    loadInitialData();
  }, []);

  const initializeUser = async () => {
    // Check if user exists in localStorage
    const savedUser = localStorage.getItem('whatsapp_user');
    
    if (savedUser) {
      const user = JSON.parse(savedUser) as User;
      dispatch({ type: 'SET_USER', payload: user });
      return;
    }

    // Create new user
    try {
      const peerId = generatePeerId();
      const username = `user_${Date.now()}`;
      
      const response = await fetch('/api/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username,
          peerId,
          name: 'You',
          status: 'Hey there! I am using WhatsApp Clone.'
        })
      });

      if (response.ok) {
        const user = await response.json();
        localStorage.setItem('whatsapp_user', JSON.stringify(user));
        dispatch({ type: 'SET_USER', payload: user });
        
        toast({
          title: "Welcome!",
          description: "Your account has been created successfully.",
        });
      } else {
        throw new Error('Failed to create user');
      }
    } catch (error) {
      console.error('Failed to initialize user:', error);
      toast({
        title: "Error",
        description: "Failed to initialize user account.",
        variant: "destructive",
      });
    }
  };

  const loadInitialData = async () => {
    if (!state.currentUser) return;

    try {
      // Load chats
      const chatsResponse = await fetch(`/api/chats/${state.currentUser.id}`);
      if (chatsResponse.ok) {
        const chats = await chatsResponse.json();
        dispatch({ type: 'SET_CHATS', payload: chats });
      }

      // Load contacts
      const contactsResponse = await fetch(`/api/contacts/${state.currentUser.id}`);
      if (contactsResponse.ok) {
        const contacts = await contactsResponse.json();
        dispatch({ type: 'SET_CONTACTS', payload: contacts });
      }

      // Load status updates
      const statusResponse = await fetch(`/api/status/contacts/${state.currentUser.id}`);
      if (statusResponse.ok) {
        const statusUpdates = await statusResponse.json();
        dispatch({ type: 'SET_STATUS_UPDATES', payload: statusUpdates });
      }
    } catch (error) {
      console.error('Failed to load initial data:', error);
    }
  };

  const generatePeerId = () => {
    return 'peer_' + Math.random().toString(36).substr(2, 9) + '_' + Date.now();
  };

  return (
    <div className="flex h-screen bg-gray-100 dark:bg-gray-900" data-testid="main-container">
      <ChatSidebar 
        onShowStatus={() => setShowStatusModal(true)}
        onShowGroup={() => setShowGroupModal(true)}
        onShowContact={() => setShowContactModal(true)}
        data-testid="chat-sidebar"
      />
      
      <div className="flex-1 flex">
        <ChatArea 
          onShowContactInfo={() => setShowContactInfo(true)}
          data-testid="chat-area"
        />
        
        {showContactInfo && (
          <ContactInfo 
            onClose={() => setShowContactInfo(false)}
            data-testid="contact-info"
          />
        )}
      </div>

      {showStatusModal && (
        <StatusModal
          isOpen={showStatusModal}
          onClose={() => setShowStatusModal(false)}
          data-testid="status-modal"
        />
      )}

      {showGroupModal && (
        <GroupModal
          isOpen={showGroupModal}
          onClose={() => setShowGroupModal(false)}
          data-testid="group-modal"
        />
      )}

      {showContactModal && (
        <ContactModal
          isOpen={showContactModal}
          onClose={() => setShowContactModal(false)}
          data-testid="contact-modal"
        />
      )}
    </div>
  );
}
