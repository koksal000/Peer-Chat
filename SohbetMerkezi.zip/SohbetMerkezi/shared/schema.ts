import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, boolean, jsonb, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  peerId: text("peer_id").notNull().unique(),
  name: text("name").notNull(),
  avatar: text("avatar"),
  status: text("status").default("Available"),
  isOnline: boolean("is_online").default(false),
  lastSeen: timestamp("last_seen").defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Contacts table
export const contacts = pgTable("contacts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  contactId: varchar("contact_id").references(() => users.id).notNull(),
  displayName: text("display_name"),
  isBlocked: boolean("is_blocked").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// Chats table
export const chats = pgTable("chats", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  type: text("type").notNull(), // 'individual', 'group', 'ai'
  name: text("name"),
  description: text("description"),
  avatar: text("avatar"),
  createdBy: varchar("created_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Chat participants
export const chatParticipants = pgTable("chat_participants", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  chatId: varchar("chat_id").references(() => chats.id).notNull(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  role: text("role").default("member"), // 'admin', 'member'
  joinedAt: timestamp("joined_at").defaultNow(),
});

// Messages table
export const messages = pgTable("messages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  chatId: varchar("chat_id").references(() => chats.id).notNull(),
  senderId: varchar("sender_id").references(() => users.id).notNull(),
  type: text("type").notNull(), // 'text', 'image', 'video', 'file', 'audio', 'location'
  content: text("content").notNull(),
  metadata: jsonb("metadata"), // File info, location data, etc.
  replyToId: varchar("reply_to_id").references(() => messages.id),
  isEdited: boolean("is_edited").default(false),
  isDeleted: boolean("is_deleted").default(false),
  timestamp: timestamp("timestamp").defaultNow(),
});

// Message status
export const messageStatus = pgTable("message_status", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  messageId: varchar("message_id").references(() => messages.id).notNull(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  status: text("status").notNull(), // 'sent', 'delivered', 'read'
  timestamp: timestamp("timestamp").defaultNow(),
});

// Status updates
export const statusUpdates = pgTable("status_updates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  type: text("type").notNull(), // 'text', 'image', 'video'
  content: text("content").notNull(),
  caption: text("caption"),
  privacyLevel: text("privacy_level").default("contacts"), // 'contacts', 'public', 'custom'
  viewCount: integer("view_count").default(0),
  createdAt: timestamp("created_at").defaultNow(),
  expiresAt: timestamp("expires_at"), // Status expires after 24 hours
});

// Status views
export const statusViews = pgTable("status_views", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  statusId: varchar("status_id").references(() => statusUpdates.id).notNull(),
  viewerId: varchar("viewer_id").references(() => users.id).notNull(),
  viewedAt: timestamp("viewed_at").defaultNow(),
});

// Files table
export const files = pgTable("files", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  filename: text("filename").notNull(),
  originalName: text("original_name").notNull(),
  mimeType: text("mime_type").notNull(),
  size: integer("size").notNull(),
  uploadedBy: varchar("uploaded_by").references(() => users.id).notNull(),
  filePath: text("file_path").notNull(),
  uploadedAt: timestamp("uploaded_at").defaultNow(),
});

// Zod schemas for validation
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  peerId: true,
  name: true,
  avatar: true,
  status: true,
});

export const insertContactSchema = createInsertSchema(contacts).pick({
  userId: true,
  contactId: true,
  displayName: true,
});

export const insertChatSchema = createInsertSchema(chats).pick({
  type: true,
  name: true,
  description: true,
  avatar: true,
  createdBy: true,
});

export const insertMessageSchema = createInsertSchema(messages).pick({
  chatId: true,
  senderId: true,
  type: true,
  content: true,
  metadata: true,
  replyToId: true,
});

export const insertStatusSchema = createInsertSchema(statusUpdates).pick({
  userId: true,
  type: true,
  content: true,
  caption: true,
  privacyLevel: true,
});

// Type exports
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Contact = typeof contacts.$inferSelect;
export type InsertContact = z.infer<typeof insertContactSchema>;
export type Chat = typeof chats.$inferSelect;
export type InsertChat = z.infer<typeof insertChatSchema>;
export type Message = typeof messages.$inferSelect;
export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type StatusUpdate = typeof statusUpdates.$inferSelect;
export type InsertStatus = z.infer<typeof insertStatusSchema>;
export type FileUpload = typeof files.$inferSelect;

// WebSocket message types
export type WSMessage = {
  type: 'message' | 'typing' | 'status' | 'call' | 'notification';
  data: any;
  targetUser?: string;
  chatId?: string;
};
